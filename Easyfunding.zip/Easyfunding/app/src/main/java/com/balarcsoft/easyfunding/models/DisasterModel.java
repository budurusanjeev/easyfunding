package com.balarcsoft.easyfunding.models;

/**
 * Created by BS-2 on 4/18/2016.
 */
public class DisasterModel {
    String disasterName;

    public int getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(int imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getDisasterName() {
        return disasterName;
    }

    public void setDisasterName(String disasterName) {
        this.disasterName = disasterName;
    }

    int imageUrl;
}
