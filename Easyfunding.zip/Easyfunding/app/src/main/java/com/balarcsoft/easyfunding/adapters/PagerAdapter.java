package com.balarcsoft.easyfunding.adapters;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import com.balarcsoft.easyfunding.AlmostComplete;
import com.balarcsoft.easyfunding.Latest;
import com.balarcsoft.easyfunding.LessTimeToComoplete;
import com.balarcsoft.easyfunding.MostPopular;

/**
 * Created by BS-2 on 4/18/2016.
 */
public class PagerAdapter extends FragmentStatePagerAdapter {
    int mNumOfTabs;
    String name;
    String mode,campaignerId;
Context context;
    public PagerAdapter(FragmentManager fm, int NumOfTabs, String name, String mode, String campaignerId, Context applicationContext) {
        super(fm);
        this.mNumOfTabs = NumOfTabs;
        this.name=name;
        this.mode=mode;
        this.context= applicationContext;
        this.campaignerId= campaignerId;
    }

    @Override
    public Fragment getItem(int position) {

            switch (position) {
                case 0:
                    Latest latest = new Latest();
                    return latest;
                case 1:
                    MostPopular mostPopular = new MostPopular();
                    return mostPopular;
                case 2:
                    LessTimeToComoplete lessTimeToComoplete = new LessTimeToComoplete();
                    return lessTimeToComoplete;
                case 3:
                    AlmostComplete almostComplete = new AlmostComplete();
                    return almostComplete;
                default:
                    return null;
            }
    }

    @Override
    public int getCount() {
        return mNumOfTabs;
    }
}
