package com.balarcsoft.easyfunding;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputLayout;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.balarcsoft.easyfunding.network.NetworkCheck;
import com.balarcsoft.easyfunding.utils.AppPreferences;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by BS-2 on 4/18/2016.
 */
public class SignUp extends BaseActivity {
    private static final String EMAIL_PATTERN = "^[a-zA-Z0-9#_~!$&'()*+,;=:.\"(),:;<>@\\[\\]\\\\]+@[a-zA-Z0-9-]+(\\.[a-zA-Z0-9-]+)*$";
    private Pattern pattern = Pattern.compile(EMAIL_PATTERN);
    private Matcher matcher;
    boolean iAgree,validateViews;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup);

        final LinearLayout linearLayout = (LinearLayout)findViewById(R.id.linearLayout);
        final TextInputLayout firstName = (TextInputLayout)findViewById(R.id.input_layout_name);
        final TextInputLayout lastName = (TextInputLayout)findViewById(R.id.input_layout_last_name);
        final TextInputLayout password = (TextInputLayout)findViewById(R.id.input_layout_password);
        final TextInputLayout email    = (TextInputLayout)findViewById(R.id.input_layout_email);
        final TextView forgotPassword=(TextView)findViewById(R.id.forgotPassword);
        final CheckBox checkBox = (CheckBox)findViewById(R.id.agreecCheckbox);
        Button signUp=(Button)findViewById(R.id.sign);

        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(buttonView.isChecked())
                {
                    iAgree=true;
                }
                else
                {
                    iAgree=false;
                }
            }
        });

        forgotPassword.setVisibility(View.GONE);

        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (firstName.getEditText().getText().toString().equals("")) {
                    firstName.setErrorEnabled(true);
                    firstName.setError("You need to enter a first name");
                    validateViews = true;
                } else {
                    firstName.setError(null);
                    firstName.setErrorEnabled(false);
                    validateViews = false;
                }

                if (lastName.getEditText().getText().toString().equals("")) {
                    lastName.setErrorEnabled(true);
                    lastName.setError("You need to enter a last name");
                    validateViews = true;
                } else {
                    lastName.setError(null);
                    lastName.setErrorEnabled(false);
                    validateViews = false;
                }

                if (email.getEditText().getText().toString().equals("")) {
                    validateViews = true;
                    email.setErrorEnabled(true);
                    email.setError("You need to enter a email");
                } else {
                    email.setError(null);
                    email.setErrorEnabled(false);
                    validateViews = false;
                }


                if (password.getEditText().getText().toString().equals("")) {
                    password.setErrorEnabled(true);
                    password.setError("You need to enter a password");
                    validateViews = true;
                } else {
                    password.setError(null);
                    password.setErrorEnabled(false);
                    validateViews = false;
                }

                if (password.getEditText().getText().length() < 6) {
                    password.setErrorEnabled(true);
                    password.setError("Maximum length of password is 6");
                    validateViews = true;
                } else {
                    password.setError(null);
                    password.setErrorEnabled(false);
                    validateViews = false;

                }
                if (!validateEmail(email.getEditText().getText().toString())) {
                    email.setErrorEnabled(true);
                    email.setError("Not a valid email address!");
                    validateViews = true;
                } else {
                    email.setError(null);
                    email.setErrorEnabled(false);
                    validateViews = false;
                }

                if (!iAgree) {
                    validateViews = true;
                    Toast.makeText(getApplicationContext(), "Agree terms is missing", Toast.LENGTH_LONG).show();
                } else {
                    validateViews = false;
                }


                if (!validateViews)

                {
                    String connection = NetworkCheck.getConnectivityStatusString(getApplicationContext());
                    JSONObject jsonObject = null;
                    if (!connection.equals("No Internet Connection")) {
                        try {
                            jsonObject = new JSONObject();
                            jsonObject.put("firstName", firstName.getEditText().getText().toString());
                            jsonObject.put("lastName", lastName.getEditText().getText().toString());
                            jsonObject.put("username", email.getEditText().getText().toString());
                            jsonObject.put("password", password.getEditText().getText().toString());
                            jsonObject.put("type", "campaigner");
                            sendRequest(jsonObject);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    } else {
                        Snackbar snackbar = Snackbar.make(linearLayout, "No Internet Connection ", Snackbar.LENGTH_INDEFINITE);
                        snackbar.getView().setBackgroundColor(Color.WHITE);
                        View snackbarView = snackbar.getView();
                        TextView textView = (TextView) snackbarView.findViewById(android.support.design.R.id.snackbar_text);
                        textView.setTextColor(Color.parseColor("#0a6b58"));
                        snackbar.show();
                    }
                }


            }
        });


    }

    private void sendRequest(JSONObject jsonObject)
    {
        String url = Constants.SIGN_UP;
        JsonObjectRequest stringRequest = new JsonObjectRequest(1,url,jsonObject,new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                        Toast.makeText(getApplicationContext()," Success "+response,Toast.LENGTH_SHORT).show();
                startActivity(new Intent(SignUp.this, SignIn.class));
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                String body= null;
                //get status code here
             //   String statusCode = String.valueOf(error.networkResponse.statusCode);
                //get response body and parse with appropriate encoding
                if (error instanceof TimeoutError || error instanceof NoConnectionError)
                {
                    Toast.makeText(getApplicationContext(), "ConnectionError",
                            Toast.LENGTH_LONG).show();
                } else if (error instanceof ServerError)
                {

                    Toast.makeText(getApplicationContext(), "ServerError",
                            Toast.LENGTH_LONG).show();
                } else if (error instanceof NetworkError)
                {
                    Toast.makeText(getApplicationContext(), "NetworkError",
                            Toast.LENGTH_LONG).show();

                }
                else
                if(error.networkResponse.data!=null) {
                    try {
                        body = new String(error.networkResponse.data,"UTF-8");
                        JSONObject failJsonObject = new JSONObject(body);
                        new android.app.AlertDialog.Builder(SignUp.this)
                                .setMessage(failJsonObject.getString("message"))
                                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.cancel();
                                    }
                                })
                                .show();
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

               // Toast.makeText(getApplicationContext()," "+body,Toast.LENGTH_LONG).show();
            }
        }){
            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("content-Type", "application/json");
                params.put("Accept", "application/json");
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    public boolean validateEmail(String email) {
        matcher = pattern.matcher(email);
        return matcher.matches();
    }
}
