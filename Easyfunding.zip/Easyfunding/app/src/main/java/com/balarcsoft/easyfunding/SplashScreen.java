package com.balarcsoft.easyfunding;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.AsyncTask;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.balarcsoft.easyfunding.post.PostDataWebService;
import com.balarcsoft.easyfunding.network.NetworkChangeReceiver;
import com.balarcsoft.easyfunding.utils.AppPreferences;
import com.google.android.gms.analytics.HitBuilders;
import com.google.android.gms.analytics.Tracker;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class SplashScreen extends AppCompatActivity {
    NetworkChangeReceiver connectionBroadcast;
    Tracker mTracker;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash_screen);
        EasyFundingApplication application = (EasyFundingApplication) getApplication();
        mTracker = application.getDefaultTracker();
     final RelativeLayout relativeLayout = (RelativeLayout)findViewById(R.id.relative);

        connectionBroadcast  = new NetworkChangeReceiver() {
            @Override
            public void onNetworkChange(String connection) {
                if(connection.equals("No Internet Connection"))
                {

                    Snackbar snackbar=Snackbar.make(relativeLayout, "No Internet Connection ", Snackbar.LENGTH_INDEFINITE);
                    snackbar.getView().setBackgroundColor(Color.WHITE);
                    View snackbarView = snackbar.getView();
                    TextView textView = (TextView) snackbarView.findViewById(android.support.design.R.id.snackbar_text);
                    textView.setTextColor(Color.parseColor("#0a6b58"));
                    snackbar.show();
                }else
                {
                 EasyFundingApplication appPreferences = (EasyFundingApplication)getApplicationContext();
                   // AppPreferences appPreferences = new AppPreferences(getApplicationContext());

                             if(!TextUtils.isEmpty(appPreferences.getInstance().getEmailId()))
                        {
                            String loginCredentials = "Password=" +appPreferences.getInstance().getPassword() + "&Username=" +appPreferences.getInstance().getEmailId();
                            String url = Constants.SIGN_IN;
                            ArrayList values = new ArrayList();
                            values.add(loginCredentials);
                            values.add(url);
                         //   new Loginasynctask().execute(values);
                            //finish();
                            sendRequest();
                        } else
                        {
                            Thread background = new Thread() {
                                public void run() {

                                    try {
                                        // Thread will sleep for 5 seconds
                                        sleep(3 * 1000);

                                        // After 3 seconds redirect to another intent
                                        Intent i = new Intent(getBaseContext(), DisasterList.class);
                                        startActivity(i);

                                        //Remove activity
                                        finish();

                                    } catch (Exception e) {

                                    }
                                }
                            };

                            // start thread
                            background.start();
                        }
                    }
            }
        };


    }

    private void sendRequest() {
        EasyFundingApplication appPreferences = (EasyFundingApplication)getApplicationContext();
        final String loginCredentials    = "Password=" +appPreferences.getInstance().getPassword() + "&Username=" +appPreferences.getInstance().getEmailId();
        String url = Constants.SIGN_IN;

        StringRequest stringRequest = new StringRequest(1,url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try
                        {
                            JSONObject loginSuccess = new JSONObject(response);
                            AppPreferences appPreferences = new AppPreferences(getApplicationContext());
                            appPreferences.setEmailId(loginSuccess.getString("userName"));
                            appPreferences.setProfileId(loginSuccess.getString("profileId"));
                           // appPreferences.setPassword(password.getEditText().getText().toString());
                            Toast.makeText(getApplicationContext(),"Login Success ",Toast.LENGTH_LONG).show();
                            startActivity(new Intent(getApplicationContext(), MyCampaign.class));
                            finish();
                        }
                        catch (Exception e)
                        {
                            e.printStackTrace();
                        }

                    }
                },

                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        if (error instanceof TimeoutError || error instanceof NoConnectionError)
                        {
                            Toast.makeText(getApplicationContext(), "ConnectionError",
                                    Toast.LENGTH_LONG).show();
                        } else if (error instanceof ServerError)
                        {

                            Toast.makeText(getApplicationContext(), "ServerError",
                                    Toast.LENGTH_LONG).show();
                        } else if (error instanceof NetworkError)
                        {
                            Toast.makeText(getApplicationContext(), "NetworkError",
                                    Toast.LENGTH_LONG).show();

                        }
                        else if(error.networkResponse.data!=null) {
                            String body= null;
                            //get status code here
                            //   String statusCode = String.valueOf(error.networkResponse.statusCode);
                            //get response body and parse with appropriate encoding
                            try {
                                body = new String(error.networkResponse.data,"UTF-8");
                                JSONObject failJsonObject = new JSONObject(body);
                                new android.app.AlertDialog.Builder(SplashScreen.this)
                                        .setMessage(failJsonObject.getString("message"))
                                        .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int which) {
                                                dialog.cancel();
                                            }
                                        })
                                        .show();
                            } catch (UnsupportedEncodingException e) {
                                e.printStackTrace();
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }

                    }
                })
        {
            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("content-Type", "application/x-www-form-urlencoded");
                // volley will escape this for you
                params.put("Accept", "application/json");
                return params;
            }
            @Override
            public byte[] getBody() throws AuthFailureError {
                //  String httpPostBody="grant_type=password&username=Alice&password=password123";
                // usually you'd have a field with some values you'd want to escape, you need to do it yourself if overriding getBody. here's how you do it
               /* try {
                   // loginCredentials=loginCredentials+"&randomFieldFilledWithAwkwardCharacters="+ URLEncoder.encode("{{%stuffToBe Escaped/", "UTF-8");
                } catch (UnsupportedEncodingException exception) {
                    Log.e("ERROR", "exception", exception);
                    // return null and don't pass any POST string if you encounter encoding error
                    return null;
                }*/
                return loginCredentials.getBytes();
            }
            @Override
            protected Response<String> parseNetworkResponse(NetworkResponse response) {

                try {
                    if(response!=null) {
                        String json = new String(
                                response.data, HttpHeaderParser.parseCharset(response.headers));
                        AppPreferences appPreferences ;
                        //appPreferences.setTokenId(response.headers.get("token"));
                        //String cookie = response.headers.get("Set-Cookie");
                        String cookie = response.headers.get("Set-Cookie");
                        if(response.headers.get("token")!=null)
                        {
                            appPreferences= new AppPreferences(getApplicationContext());
                            appPreferences.setTokenId(response.headers.get("token"));
                        }
                        if(cookie!=null) {
                            String[] abc = cookie.split(";");
                            Log.v("cookie", "cookie" + abc[0]);
                            Log.v("cookie", "cookie" + abc[1]);
                            Log.v("cookie", "cookie" + cookie);
                            appPreferences= new AppPreferences(getApplicationContext());
                            appPreferences.setSessionId(abc[0]);
                        }
                        return Response.success(
                                json, HttpHeaderParser.parseCacheHeaders(response));
                    }
                } catch (UnsupportedEncodingException e) {
                    return Response.error(new ParseError(e));
                }
                return null;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    public class Loginasynctask extends AsyncTask<ArrayList, SignupResponse, SignupResponse> {
        SignupResponse signupResponse;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected SignupResponse doInBackground(ArrayList... params) {
            String jobject= (String) params[0].get(0);
            String url= (String) params[0].get(1);

            try
            {

                signupResponse = PostDataWebService.postWebServiceData(jobject, url, getApplicationContext());
            }
            catch (final Exception e)
            {
                e.printStackTrace();

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getApplicationContext(), "" + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
                Log.v("server Exception", "Exception : "
                        + e.getMessage(), e);
            }

            return signupResponse;
        }

        @Override
        protected void onPostExecute(SignupResponse signupResponse) {
            super.onPostExecute(signupResponse);
            if(!TextUtils.isEmpty(signupResponse.getResponse()))
            {
                if(signupResponse.getResponse().equals("200"))
                {
                    try
                    {
                        JSONObject loginSuccess = new JSONObject(signupResponse.getResult());
                        AppPreferences appPreferences = new AppPreferences(getApplicationContext());
                        appPreferences.setEmailId(loginSuccess.getString("userName"));
                        appPreferences.setProfileId(loginSuccess.getString("profileId"));
                      //  Toast.makeText(getApplicationContext(),"Login Success ",Toast.LENGTH_LONG).show();
                        startActivity(new Intent(getApplicationContext(), MyCampaign.class));
                        Log.v("login success", "login success" + loginSuccess.getString("userName"));
                    }
                    catch (Exception e)
                    {
                        e.printStackTrace();
                    }

                }
                else
                {
                    try
                    {
                        JSONObject loginFail = new JSONObject(signupResponse.getResult());
                        Toast.makeText(getApplicationContext(),"Login Failed "+ loginFail.getString("message"),Toast.LENGTH_LONG).show();
                        startActivity(new Intent(getApplicationContext(), SignIn.class));
                        Log.v("login success", "login success" +loginFail.getString("message") );
                    }
                    catch (Exception e)
                    {
                        e.printStackTrace();
                    }
                }
            }else
            {
                Toast.makeText(getApplicationContext(),"Due to network issue unable to connect to server",Toast.LENGTH_LONG).show();
            }
        }
    }
    @Override
    protected void onResume() {
        super.onResume();
        getApplicationContext().registerReceiver(connectionBroadcast, new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"));
        mTracker.setScreenName("Splash screen");
        mTracker.send(new HitBuilders.ScreenViewBuilder().build());
    }

    @Override
    protected void onPause() {
        super.onPause();
        getApplicationContext().unregisterReceiver(connectionBroadcast);
    }
}
