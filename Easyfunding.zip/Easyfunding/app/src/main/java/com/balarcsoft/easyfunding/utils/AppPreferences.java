package com.balarcsoft.easyfunding.utils;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import com.balarcsoft.easyfunding.R;


/**
 * Created by 100251 on 3/16/2015.
 */
public class AppPreferences {

    public Context mContext;
    SharedPreferences.Editor sharedPreferences;

    public AppPreferences(Context context)
    {
        mContext = context;
    }
    private SharedPreferences.Editor getSharedPreferences()
    {
        if(sharedPreferences == null) {
            sharedPreferences =  mContext.getSharedPreferences(mContext.getString(R.string.app_name), Activity.MODE_PRIVATE).edit();
        }
        return sharedPreferences;
    }
    public void setSessionId(String sessionId) {
        SharedPreferences.Editor editor =getSharedPreferences();
        editor.putString("SessionId", sessionId);
        editor.commit();
    }

    public String getTokenId() {
        String deviceId = mContext.getSharedPreferences(mContext.getString(R.string.app_name), Activity.MODE_PRIVATE).getString("tokenId", "");
        return deviceId;
    }

    public void setTokenId(String tokenId) {
        SharedPreferences.Editor editor = getSharedPreferences();
        editor.putString("tokenId", tokenId);
        editor.commit();
    }

    public String getMode() {
        String mode = mContext.getSharedPreferences(mContext.getString(R.string.app_name), Activity.MODE_PRIVATE).getString("mode", "");
        return mode;
    }

    public void setMode(String mode) {
        SharedPreferences.Editor editor = getSharedPreferences();
        editor.putString("mode", mode);
        editor.commit();
    }


    public String getCampaignerId() {
        String campaignerId = mContext.getSharedPreferences(mContext.getString(R.string.app_name), Activity.MODE_PRIVATE).getString("campaignerId", "");
        return campaignerId;
    }

    public void setCampaignerId(String campaignerId) {
        SharedPreferences.Editor editor = getSharedPreferences();
        editor.putString("campaignerId", campaignerId);
        editor.commit();
    }


    public String getSessionId() {
        String deviceId = mContext.getSharedPreferences(mContext.getString(R.string.app_name), Activity.MODE_PRIVATE).getString("SessionId", "");
        return deviceId;
    }

    public String getProfileId()
    {
        String userMode = mContext.getSharedPreferences(mContext.getString(R.string.app_name), Activity.MODE_PRIVATE).getString("profileId", "");
        return userMode;
    }

    public void setProfileId(String profileId)
    {
        SharedPreferences.Editor editor = getSharedPreferences();
        editor.putString("profileId", profileId);
        editor.commit();
    }
    public String getEmailId()
    {
        String userMode = mContext.getSharedPreferences(mContext.getString(R.string.app_name), Activity.MODE_PRIVATE).getString("emailId", "");
        return userMode;
    }

    public void setEmailId(String profileId)
    {
        SharedPreferences.Editor editor = getSharedPreferences();
        editor.putString("emailId", profileId);
        editor.commit();
    }
    public String getPassword()
    {
        String userMode = mContext.getSharedPreferences(mContext.getString(R.string.app_name), Activity.MODE_PRIVATE).getString("password", "");
        return userMode;
    }

    public void setPassword(String password)
    {
        SharedPreferences.Editor editor = getSharedPreferences();
        editor.putString("password", password);
        editor.commit();
    }
}
