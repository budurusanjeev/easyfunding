package com.balarcsoft.easyfunding;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.balarcsoft.easyfunding.adapters.ImagePagerAdapter;
import com.balarcsoft.easyfunding.get.GetAsyncTask;
import com.balarcsoft.easyfunding.network.NetworkCheck;
import com.balarcsoft.easyfunding.post.ImageUploadAsyncTask;
import com.balarcsoft.easyfunding.utils.AppPreferences;
import com.google.android.gms.analytics.HitBuilders;
import com.google.android.gms.analytics.Tracker;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by BS-2 on 4/19/2016.
 */
public class DetailDisaster extends AppCompatActivity {

    String id;
    Tracker mTracker;
    Button  goalAmount,donatedAmount;
    TextView description;
    ViewPager viewPager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
     setContentView(R.layout.sampleviewpager);
        EasyFundingApplication application = (EasyFundingApplication) getApplication();
        mTracker = application.getDefaultTracker();
        final LinearLayout linearLayout = (LinearLayout)findViewById(R.id.linearLayout);
        id= getIntent().getExtras().getString("campaignId");
        viewPager =(ViewPager)findViewById(R.id.image_pager);
        viewPager.setClipToPadding(false);
        // set padding manually, the more you set the padding the more you see of prev & next page
        viewPager.setPadding(40, 0, 40, 0);
        // sets a margin b/w individual pages to ensure that there is a gap b/w them
        viewPager.setPageMargin(20);
        description  = (TextView)findViewById(R.id.description);
        FloatingActionButton makeDonation=(FloatingActionButton)findViewById(R.id.makeDonation);
          goalAmount=(Button)findViewById(R.id.goal);
          donatedAmount=(Button)findViewById(R.id.need);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
       // getSupportActionBar().setDisplayHomeAsUpEnabled(true);
       // getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_back);
        toolbar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        CollapsingToolbarLayout collapsingToolbar =
                (CollapsingToolbarLayout) findViewById(R.id.collapsing_toolbar);
        collapsingToolbar.setTitle(getResources().getString(R.string.app_name));

        String   connection = NetworkCheck.getConnectivityStatusString(getApplicationContext());

        if (!connection.equals("No Internet Connection"))
        {
            sendRequest();

        }else
        {
            Snackbar snackbar = Snackbar.make(linearLayout, "No Internet Connection ", Snackbar.LENGTH_INDEFINITE);
            snackbar.getView().setBackgroundColor(Color.WHITE);
            View snackbarView = snackbar.getView();
            TextView textView = (TextView) snackbarView.findViewById(android.support.design.R.id.snackbar_text);
            textView.setTextColor(Color.parseColor("#0a6b58"));
            snackbar.show();
        }
        makeDonation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String connection = NetworkCheck.getConnectivityStatusString(getApplicationContext());
                if (!connection.equals("No Internet Connection")) {
                    startActivity(new Intent(getApplicationContext(), DonatingAmount.class).putExtra("campaignId",id));

                } else {
                    Snackbar snackbar = Snackbar.make(linearLayout, "No Internet Connection ", Snackbar.LENGTH_INDEFINITE);
                    snackbar.getView().setBackgroundColor(Color.WHITE);
                    View snackbarView = snackbar.getView();
                    TextView textView = (TextView) snackbarView.findViewById(android.support.design.R.id.snackbar_text);
                    textView.setTextColor(Color.parseColor("#0a6b58"));
                    snackbar.show();
                }

            }
        });
    }






    private void sendRequest() {
        JSONObject jsonObject = new JSONObject();
        try {

            Log.v("json", "json  " + jsonObject.toString());
        }catch (Exception e)
        {
            e.printStackTrace();
        }
        String url = Constants.SINGLE_CAMPAIGN+id;

        JsonObjectRequest stringRequest = new JsonObjectRequest(Request.Method.GET,url,jsonObject,new Response.Listener<JSONObject>()
        {
            @Override
            public void onResponse(JSONObject response) {

                try{

                    goalAmount.setText(response.getString("amount"));

                    if (!response.getString("totalDonations").equals("null"))
                    {
                        donatedAmount.setText(response.getString("totalDonations"));
                    } else
                    {
                        donatedAmount.setText("0.0");
                    }
                    description.setText(response.getString("description"));
                    JSONArray jsonArray = response.getJSONArray("images");
                    int count = jsonArray.length();
                    ArrayList arrayList1 = new ArrayList();
                    for (int s = 0; s < count; s++) {
                        JSONObject jsonObject1 = jsonArray.getJSONObject(s);
                        arrayList1.add(jsonObject1.getString("imageUrl"));
                    }
                    ImagePagerAdapter imagePagerAdapter = new ImagePagerAdapter(getApplicationContext(), arrayList1);
                    viewPager.setAdapter(imagePagerAdapter);
                }catch (Exception e )
                {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                String body= null;
                //get status code here
                //   String statusCode = String.valueOf(error.networkResponse.statusCode);
                //get response body and parse with appropriate encoding
                if (error instanceof TimeoutError || error instanceof NoConnectionError)
                {
                    Toast.makeText(getApplicationContext(), "ConnectionError",
                            Toast.LENGTH_LONG).show();
                } else if (error instanceof ServerError)
                {

                    Toast.makeText(getApplicationContext(), "ServerError",
                            Toast.LENGTH_LONG).show();
                } else if (error instanceof NetworkError)
                {
                    Toast.makeText(getApplicationContext(), "NetworkError",
                            Toast.LENGTH_LONG).show();

                }else if(error.networkResponse.data!=null) {
                    try {
                        body = new String(error.networkResponse.data,"UTF-8");
                        Log.v("error","error  "+body);
                        Log.v("error","error  "+body);
                        JSONObject failJsonObject = new JSONObject(body);
                        new android.app.AlertDialog.Builder(DetailDisaster.this)
                                .setMessage(failJsonObject.getString("message"))
                                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.cancel();
                                    }
                                })
                                .show();
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

            }
        })
        {

            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("content-Type", "application/json");
                params.put("Accept", "application/json");
                return params;
            }

            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                final AppPreferences  appPreferences = new AppPreferences(getApplicationContext());
                Map<String, String>  params = new HashMap<String, String>();
                params.put("Cookie", appPreferences.getSessionId().trim());
                params.put("token", appPreferences.getTokenId().trim());
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }

    @Override
    protected void onResume() {
        super.onResume();
        mTracker.setScreenName("Detail Disaster");
        mTracker.send(new HitBuilders.ScreenViewBuilder().build());
    }
}
