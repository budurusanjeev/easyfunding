package com.balarcsoft.easyfunding;

import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.balarcsoft.easyfunding.adapters.DonationListAdapter;
import com.balarcsoft.easyfunding.adapters.MyCampaignAdapter;
import com.balarcsoft.easyfunding.models.DonationModel;
import com.balarcsoft.easyfunding.models.MyCampaignModel;
import com.balarcsoft.easyfunding.network.NetworkCheck;
import com.balarcsoft.easyfunding.utils.AppPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by BS-2 on 4/30/2016.
 */
public class DonationsList extends BaseActivity{
    String gender[] = new String[]{"Select Gender","Male","Female"};
    TextInputLayout firstName,lastName,email,phone,donationAmount;
    String genderValue,campaignId;
    RecyclerView recyclerView;
    LinearLayout linear;
    ArrayList<DonationModel> donationModelArrayList;
    boolean visibility = false;
    EditText input_name,input_last_name,input_email_signup,input_phone,input_donation;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    setContentView(R.layout.donationslayout);
        Spinner genderSpinner = (Spinner)findViewById(R.id.gender);
        ArrayAdapter arrayAdapter = new ArrayAdapter(DonationsList.this,android.R.layout.simple_dropdown_item_1line,gender);
        genderSpinner.setAdapter(arrayAdapter);
       final Button offline= (Button)findViewById(R.id.offlineDonation);
        linear=(LinearLayout)findViewById(R.id.linear);
       final LinearLayout   linearLayout=(LinearLayout)findViewById(R.id.linearLayout);
        Button offlineDonation= (Button)findViewById(R.id.updateOfflineDonation);
        recyclerView=(RecyclerView)findViewById(R.id.recycler_view);
        firstName = (TextInputLayout)findViewById(R.id.input_layout_name);
        lastName = (TextInputLayout)findViewById(R.id.input_layout_last_name);
        email = (TextInputLayout)findViewById(R.id.input_layout_email);
        phone = (TextInputLayout)findViewById(R.id.input_layout_phone);
        donationAmount = (TextInputLayout)findViewById(R.id.input_layout_donation);
        campaignId=getIntent().getExtras().getString("id");
        donationModelArrayList= new ArrayList<DonationModel>();
        recyclerView.setHasFixedSize(true);
                input_name=(EditText)findViewById(R.id.input_name);
                input_last_name=(EditText)findViewById(R.id.input_last_name);
                input_email_signup=(EditText)findViewById(R.id.input_email_signup);
                input_phone=(EditText)findViewById(R.id.input_phone);
                input_donation=(EditText)findViewById(R.id.input_donation);
        LinearLayoutManager mLayoutManager = new LinearLayoutManager(this);

        // use a linear layout manager
        recyclerView.setLayoutManager(mLayoutManager);
     String connection= NetworkCheck.getConnectivityStatusString(DonationsList.this);
        if (!connection.equals("No Internet Connection"))
        {
            getDonationRequest();
        }
        else
        {
            Snackbar snackbar=Snackbar.make(linearLayout, "No Internet Connection", Snackbar.LENGTH_INDEFINITE);
            snackbar.getView().setBackgroundColor(Color.WHITE);
            View snackbarView = snackbar.getView();
            TextView textView = (TextView) snackbarView.findViewById(android.support.design.R.id.snackbar_text);
            textView.setTextColor(Color.parseColor("#0a6b58"));
            snackbar.show();
        }
        genderSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                genderValue=parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        offlineDonation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String connection = NetworkCheck.getConnectivityStatusString(getApplicationContext());

                if(!connection.equals("No Internet Connection"))
                {

                    if(!TextUtils.isEmpty(firstName.getEditText().getText().toString())
                            && !TextUtils.isEmpty(lastName.getEditText().getText().toString())
                            && !TextUtils.isEmpty(email.getEditText().getText().toString())
                            && !TextUtils.isEmpty(phone.getEditText().getText().toString())
                            && !TextUtils.isEmpty(donationAmount.getEditText().getText().toString())
                            && !(genderValue.equals("Select Gender")))
                    {

                        /*
                        * TODO need to go to payment gateway screen
                        * */
                        sendRequest();
                    }else
                    {
                        if(genderValue.equals("Select Gender"))
                        {
                            Toast.makeText(getApplicationContext(),"Missing gender",Toast.LENGTH_LONG).show();
                        }

                        if(firstName.getEditText().getText().toString().equals("")) {
                            firstName.setErrorEnabled(true);
                            firstName.setError("Enter a first name");

                        }else
                        {
                            firstName.setError(null);
                            firstName.setErrorEnabled(false);
                        }

                        if(lastName.getEditText().getText().toString().equals("")) {
                            lastName.setErrorEnabled(true);
                            lastName.setError("Enter a last name");

                        }else
                        {
                            lastName.setError(null);
                            lastName.setErrorEnabled(false);

                        }

                        if(phone.getEditText().getText().toString().equals("")) {
                            phone.setErrorEnabled(true);
                            phone.setError("Enter a Phone Number");

                        }else
                        {
                            phone.setError(null);
                            phone.setErrorEnabled(false);

                        }

                        if(donationAmount.getEditText().getText().toString().equals("")) {
                            donationAmount.setErrorEnabled(true);
                            donationAmount.setError("Enter a Donation Amount");

                        }else
                        {
                            donationAmount.setError(null);
                            donationAmount.setErrorEnabled(false);

                        }


                        if(!validateEmail(email.getEditText().getText().toString()))
                        {
                            email.setErrorEnabled(true);
                            email.setError("Not a valid Email address!");

                        }
                        else {
                            email.setError(null);
                            email.setErrorEnabled(false);

                        }
                    }
                }

            }
        });
       final View offlineDonantion = findViewById(R.id.offlinelayout);
        offline.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(visibility)
                {
                    offlineDonantion.setVisibility(View.VISIBLE);
                    recyclerView.setVisibility(View.GONE);
                    linear.setVisibility(View.GONE);
                    offline.setText("Donation List");
                visibility=false;
                }
                else
                {
                    offlineDonantion.setVisibility(View.GONE);
                    recyclerView.setVisibility(View.VISIBLE);
                    visibility=true;
                    linear.setVisibility(View.VISIBLE);
                    offline.setText("OffLine Donation");
                }
             }
        });
    }

    private void getDonationRequest() {
        AppPreferences appPreferences = new AppPreferences(getApplicationContext());
        String url = Constants.DONATIONS_LIST+appPreferences.getCampaignerId();

        JsonArrayRequest stringRequest = new JsonArrayRequest(Request.Method.GET,url,new Response.Listener<JSONArray>()
        {
            @Override
            public void onResponse(JSONArray response) {
                try {

                    int size = response.length();
                    for (int s = 0; s < size; s++) {
                        JSONObject jsonObject = response.getJSONObject(s);
                        DonationModel donationModel = new DonationModel();
                        donationModel.setAmount(jsonObject.getString("amount"));
                        donationModel.setDonatedDate(jsonObject.getString("donatedDate"));
                        donationModel.setPaymentType(jsonObject.getString("type"));
                       JSONObject profileObject = jsonObject.getJSONObject("profileDto");
                        donationModel.setName(profileObject.getString("firstName"));
                        donationModelArrayList.add(donationModel);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                DonationListAdapter mAdapter = new DonationListAdapter(donationModelArrayList, DonationsList.this);
                recyclerView.setAdapter(mAdapter);
            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                String body= null;
                //get status code here
                //   String statusCode = String.valueOf(error.networkResponse.statusCode);
                //get response body and parse with appropriate encoding
                if (error instanceof TimeoutError || error instanceof NoConnectionError)
                {
                    Toast.makeText(getApplicationContext(), "ConnectionError",
                            Toast.LENGTH_LONG).show();
                } else if (error instanceof ServerError)
                {

                    Toast.makeText(getApplicationContext(), "ServerError",
                            Toast.LENGTH_LONG).show();
                } else if (error instanceof NetworkError)
                {
                    Toast.makeText(getApplicationContext(), "NetworkError",
                            Toast.LENGTH_LONG).show();

                }else
                if(error.networkResponse.data!=null) {
                    try {
                        body = new String(error.networkResponse.data,"UTF-8");
                        Log.v("error","error  "+body);
                        Log.v("error","error  "+body);
                        JSONObject failJsonObject = new JSONObject(body);
                        new android.app.AlertDialog.Builder(DonationsList.this)
                                .setMessage(failJsonObject.getString("message"))
                                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.cancel();
                                    }
                                })
                                .show();
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

            }
        })
        {

            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("content-Type", "application/json");
                params.put("Accept", "application/json");
                return params;
            }

            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                final AppPreferences  appPreferences = new AppPreferences(getApplicationContext());
                Map<String, String>  params = new HashMap<String, String>();
                params.put("Cookie", appPreferences.getSessionId().trim());
                params.put("token", appPreferences.getTokenId().trim());
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }

    private void sendRequest()  {
        JSONObject donationProfile= null;
        try {
            donationProfile = new JSONObject();
            donationProfile.put("firstName", firstName.getEditText().getText().toString());
            donationProfile.put("lastName", lastName.getEditText().getText().toString());
            donationProfile.put("userName", email.getEditText().getText().toString());
            donationProfile.put("phone", phone.getEditText().getText().toString());
            donationProfile.put("userType", "donator");
            donationProfile.put("gender",genderValue);
            JSONObject mainJson = new JSONObject();
            mainJson.put("amount", donationAmount.getEditText().getText().toString());
            mainJson.put("campaignId", campaignId);
            mainJson.put("type", "Offline");
            mainJson.put("profileDto", donationProfile);

            final JsonObjectRequest jsonArrayRequest = new JsonObjectRequest(Constants.ADD_DONATION, mainJson ,new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response)
                {
                    input_name.setText("");
                    input_last_name.setText("");
                    input_email_signup.setText("");
                    input_phone.setText("");
                    input_donation.setText("");
                    Toast.makeText(getApplicationContext(),"Amount transferred successfully ",Toast.LENGTH_LONG).show();
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                    String body= null;
                    //get status code here

                    // String statusCode = String.valueOf(error.networkResponse.statusCode);

                    //get response body and parse with appropriate encoding

                    if (error instanceof TimeoutError || error instanceof NoConnectionError) {
                        Toast.makeText(getApplicationContext(), "ConnectionError",
                                Toast.LENGTH_LONG).show();
                    } else if (error instanceof ServerError) {

                        Toast.makeText(getApplicationContext(), "ServerError",
                                Toast.LENGTH_LONG).show();
                    } else if (error instanceof NetworkError) {
                        Toast.makeText(getApplicationContext(), "NetworkError",
                                Toast.LENGTH_LONG).show();

                    }else if(error.networkResponse.data!=null) {
                        try {
                            body = new String(error.networkResponse.data, "UTF-8");

                            JSONObject failJsonObject = new JSONObject(body);
                            new android.app.AlertDialog.Builder(DonationsList.this)
                                    .setMessage(failJsonObject.getString("message"))
                                    .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int which) {
                                            dialog.cancel();
                                        }
                                    })
                                    .show();
                        } catch (UnsupportedEncodingException e) {
                            e.printStackTrace();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                }
            })
            {
                @Override
                protected Map<String, String> getParams()
                {
                    Map<String, String>  params = new HashMap<String, String>();
                    params.put("content-Type", "application/json");
                    params.put("Accept", "application/json");
                    return params;
                }

                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    final AppPreferences appPreferences = new AppPreferences(getApplicationContext());
                    Map<String, String>  params = new HashMap<String, String>();
                    params.put("Cookie", appPreferences.getSessionId().trim());
                    params.put("token", appPreferences.getTokenId().trim());
                    return params;
                }
            };
            RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
            requestQueue.add(jsonArrayRequest);

        }catch (Exception e )
        {
            e.printStackTrace();
        }

    }

    public boolean validateEmail(String email) {
        final String EMAIL_PATTERN = "^[a-zA-Z0-9#_~!$&'()*+,;=:.\"(),:;<>@\\[\\]\\\\]+@[a-zA-Z0-9-]+(\\.[a-zA-Z0-9-]+)*$";
        Pattern pattern = Pattern.compile(EMAIL_PATTERN);
        Matcher matcher;
        matcher = pattern.matcher(email);
        return matcher.matches();
    }
}
