package com.balarcsoft.easyfunding.delete;

import android.os.AsyncTask;
import android.util.Log;

import com.balarcsoft.easyfunding.SignupResponse;
import com.balarcsoft.easyfunding.get.GetwebServiceDatanew;

import java.util.ArrayList;

/**
 * Created by BS2 on 02-07-2015.
 */
public class DeleteAsyncTask extends AsyncTask<ArrayList,String,SignupResponse> {
    SignupResponse signupResponse;

    @Override
    protected SignupResponse doInBackground(ArrayList... params)
    {
       String url = (String) params[0].get(0);
       String profile=(String) params[0].get(1);
       String sessionId =(String)params[0].get(2);
       String token =(String)params[0].get(3);
        String postReceiverUrl = url+profile;
        Log.v("TAG", "postURL: " + postReceiverUrl);
        signupResponse = DeleteWebService.deleteWebServiceData(postReceiverUrl,sessionId,token);
        Log.v("response","response"+signupResponse.getResponse());
        Log.v("response","response"+signupResponse.getResult());
       return signupResponse;
    }

}
