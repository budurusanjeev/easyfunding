package com.balarcsoft.easyfunding.post;

import android.os.AsyncTask;
import android.util.Log;

import com.balarcsoft.easyfunding.SignupResponse;

import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by BS-2 on 4/28/2016.
 */
public class ImageUploadAsyncTask extends AsyncTask<ArrayList, SignupResponse, SignupResponse> {
    SignupResponse signupResponse;
    @Override
    protected SignupResponse doInBackground(ArrayList... params) {
        String response = "";
        String url = (String) params[0].get(0);
        String jobject= (String) params[0].get(1);
        String imageId= (String) params[0].get(2);
        String token= (String)params[0].get(3);
        String sessionId =(String)params[0].get(4);
        Log.v("token", "token sess: " + sessionId);
        Log.v("token", "token sess : " + token);
        try {

            signupResponse = PostDataWebService.postImageServiceData(url,jobject,imageId,token,sessionId);
            Log.e("server response", "response: "
                    + signupResponse.getResult());
        }
        catch (Exception e)
        {
            e.printStackTrace();


            Log.v("server Exception", "Exception : "
                    + e.getMessage(), e);
        }

        return signupResponse;
    }
}
