package com.balarcsoft.easyfunding.adapters;

import android.app.Dialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomSheetBehavior;
import android.support.design.widget.BottomSheetDialogFragment;
import android.support.design.widget.CoordinatorLayout;
import android.view.View;
import android.widget.TextView;

import com.balarcsoft.easyfunding.CommentsList;
import com.balarcsoft.easyfunding.DonationsList;
import com.balarcsoft.easyfunding.PostCampaign;
import com.balarcsoft.easyfunding.R;
import com.balarcsoft.easyfunding.utils.AppPreferences;

/**
 * Created by Paul on 2/26/16.
 */
public class TutsPlusBottomSheetDialogFragment extends BottomSheetDialogFragment {

    private BottomSheetBehavior.BottomSheetCallback mBottomSheetBehaviorCallback = new BottomSheetBehavior.BottomSheetCallback() {

        @Override
        public void onStateChanged(@NonNull View bottomSheet, int newState) {
            if (newState == BottomSheetBehavior.STATE_HIDDEN) {
                dismiss();
            }

        }

        @Override
        public void onSlide(@NonNull View bottomSheet, float slideOffset) {
        }
    };

    @Override
    public void setupDialog(Dialog dialog, int style) {
        super.setupDialog(dialog, style);
        View contentView = View.inflate(getContext(), R.layout.fragment_bottom_sheet, null);
        dialog.setContentView(contentView);
        TextView donations = (TextView)dialog.findViewById(R.id.donationButton);
        TextView comments = (TextView)dialog.findViewById(R.id.commentsButton);
        TextView editCampaign = (TextView)dialog.findViewById(R.id.editButton);
        TextView withDraw = (TextView)dialog.findViewById(R.id.withdrawButton);

        donations.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AppPreferences appPreferences = new AppPreferences(getActivity());
                startActivity(new Intent(getContext(), DonationsList.class).putExtra("id",appPreferences.getCampaignerId()));
            }
        });

        comments.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getContext(), CommentsList.class));
            }
        });

        editCampaign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AppPreferences appPreferences = new AppPreferences(getContext());
                startActivity(new Intent(getContext(), PostCampaign.class));
                appPreferences.setMode("edit");
            }
        });

        withDraw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // startActivity(new Intent(getContext(),PostCampaign.class));
            }
        });


        CoordinatorLayout.LayoutParams params = (CoordinatorLayout.LayoutParams) ((View) contentView.getParent()).getLayoutParams();
        CoordinatorLayout.Behavior behavior = params.getBehavior();

        if( behavior != null && behavior instanceof BottomSheetBehavior ) {
            ((BottomSheetBehavior) behavior).setBottomSheetCallback(mBottomSheetBehaviorCallback);
        }
    }

}
