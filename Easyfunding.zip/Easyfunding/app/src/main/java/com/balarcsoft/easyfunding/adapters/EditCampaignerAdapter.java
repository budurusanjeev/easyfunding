package com.balarcsoft.easyfunding.adapters;

import android.app.Activity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.balarcsoft.easyfunding.EditCampaign;
import com.balarcsoft.easyfunding.R;
import com.balarcsoft.easyfunding.models.SingleDisasterModel;
import com.balarcsoft.easyfunding.models.UpdateCampaignModel;

import org.w3c.dom.Text;

import java.util.ArrayList;

/**
 * Created by BS-2 on 4/29/2016.
 */
public class EditCampaignerAdapter extends RecyclerView
.Adapter<EditCampaignerAdapter
.DataObjectHolder> {
public Activity context;
private ArrayList<UpdateCampaignModel> mDataset;
public EditCampaignerAdapter(ArrayList<UpdateCampaignModel> myDataset, Activity applicationContext) {
        this.mDataset = myDataset;
        this.context = applicationContext;

        }

@Override
public DataObjectHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext())
        .inflate(R.layout.updaterow, parent, false);

        DataObjectHolder dataObjectHolder = new DataObjectHolder(view);
        return dataObjectHolder;


        }
    public void add(int location, UpdateCampaignModel string) {
        insert(string, location);
    }

    public void insert(UpdateCampaignModel string, int position) {

        mDataset.add(position, string);
        notifyItemInserted(position);

    }
@Override
public void onBindViewHolder(final EditCampaignerAdapter.DataObjectHolder holder, final int position)
        {

            holder.commentDate.setText(mDataset.get(position).getPostedDate());
        holder.commentText.setText(mDataset.get(position).getUpdatedComment());
        animate(holder);
        }


    public void animate(RecyclerView.ViewHolder viewHolder) {
        final Animation animAnticipateOvershoot = AnimationUtils.loadAnimation(context, R.anim.anticipateovershoot_interpolator);
        viewHolder.itemView.setAnimation(animAnticipateOvershoot);
    }
@Override
public int getItemCount() {
        return mDataset.size();
        }


    public class DataObjectHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
    LinearLayout linearLayout;
        public TextView commentText,commentDate,removeView;
    public DataObjectHolder(View itemView) {
        super(itemView);
        linearLayout = (LinearLayout)itemView.findViewById(R.id.linearLayout);
        commentText = (TextView) itemView
                .findViewById(R.id.comment);
        commentDate = (TextView) itemView
                .findViewById(R.id.date);
        removeView= (TextView)itemView.findViewById(R.id.removeUpdate);

        removeView.setOnClickListener(this);



    }
        public void clearAnimation()
        {
            linearLayout.clearAnimation();
        }

        @Override
        public void onClick(View v) {
            if(v.equals(removeView)){
                  if(mDataset.get(getAdapterPosition()).getId()!=null) {
                      ((EditCampaign) context).deleteUpdate(mDataset.get(getAdapterPosition()).getId());
                      removeAt(getAdapterPosition());
                  }
            }
        }
    }

    @Override
    public void onViewDetachedFromWindow(DataObjectHolder holder) {

        holder.clearAnimation();
    }

   /* public void setOnItemClickListener(final AdapterView.OnItemClickListener mItemClickListener) {
        this.myClickListener = (MyClickListener) mItemClickListener;
    }*/

    public void removeAt(int position) {
        mDataset.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, mDataset.size());
    }

    /*public interface MyClickListener {
        public void onItemClick(int position, View v);
    }*/
}
