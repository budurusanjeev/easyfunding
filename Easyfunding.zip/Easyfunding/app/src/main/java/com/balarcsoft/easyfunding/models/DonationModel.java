package com.balarcsoft.easyfunding.models;

/**
 * Created by BS-2 on 6/9/2016.
 */
public class DonationModel
{
    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getAmount() {
        return Amount;
    }

    public void setAmount(String amount) {
        Amount = amount;
    }

    public String getDonatedDate() {
        return DonatedDate;
    }

    public void setDonatedDate(String donatedDate) {
        DonatedDate = donatedDate;
    }

    public String getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }

    String Name,Amount,DonatedDate,	paymentType;
}
