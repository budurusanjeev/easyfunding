package com.balarcsoft.easyfunding;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.Settings;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.GridView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.balarcsoft.easyfunding.adapters.GridView_Adapter;
import com.balarcsoft.easyfunding.network.NetworkCheck;
import com.balarcsoft.easyfunding.post.ImageUploadAsyncTask;
import com.balarcsoft.easyfunding.utils.AppPreferences;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.MultipartBuilder;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Created by BS-2 on 4/27/2016.
 */
public class CustomGallery_Activity extends AppCompatActivity implements View.OnClickListener {
    private static Button selectImages,postImages;
    private static GridView galleryImagesGridView;
    private static ArrayList<String> galleryImageUrls;
    private static GridView_Adapter imagesAdapter;
    String pos,imageId;
    RelativeLayout relativeLayout;
    ArrayList<String> selectedItems;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.customgallery_activity);
        relativeLayout = (RelativeLayout)findViewById(R.id.relative);
        selectedItems= new ArrayList<>();
        pos= getIntent().getExtras().getString("pos");
        imageId=getIntent().getExtras().getString("imageId");
        initViews();
        setListeners();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.System.canWrite(this)) {
                requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,
                        Manifest.permission.READ_EXTERNAL_STORAGE}, 2909);
            } else {
                fetchGalleryImages();
                setUpGridView();
                // continue with your code
            }
        } else {
            // continue with your code
            fetchGalleryImages();
            setUpGridView();
        }


    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case 2909: {
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Log.e("Permission", "Granted");
                } else {
                    Log.e("Permission", "Denied");
                    this.finish();
                    Toast.makeText(getApplicationContext(),"Sorry Permission not granted",Toast.LENGTH_LONG).show();
                }
                return;
            }
        }
    }


    //Init all views
    private void initViews() {
        selectImages = (Button) findViewById(R.id.selectImagesBtn);
        postImages = (Button) findViewById(R.id.selectPostBtn);
        galleryImagesGridView = (GridView) findViewById(R.id.galleryImagesGridView);

    }

    //fetch all images from gallery
    private void fetchGalleryImages() {
        final String[] columns = {MediaStore.Images.Media.DATA, MediaStore.Images.Media._ID};//get all columns of type images
        final String orderBy = MediaStore.Images.Media.DATE_TAKEN;//order data by date
        Cursor imagecursor = managedQuery(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, columns, null,
                null, orderBy + " DESC");//get all data in Cursor by sorting in DESC order

        galleryImageUrls = new ArrayList<String>();
        //Init array
        //Loop to cursor count
        for (int i = 0; i < imagecursor.getCount(); i++) {
            imagecursor.moveToPosition(i);
            int dataColumnIndex = imagecursor.getColumnIndex(MediaStore.Images.Media.DATA);//get column index
            galleryImageUrls.add(imagecursor.getString(dataColumnIndex));//get Image from column index
            System.out.println("Array path" + galleryImageUrls.get(i));
        }


    }

    //Set Up GridView method
    private void setUpGridView() {
        imagesAdapter = new GridView_Adapter(CustomGallery_Activity.this, galleryImageUrls, true);
        galleryImagesGridView.setAdapter(imagesAdapter);
    }

    //Set Listeners method
    private void setListeners() {

        selectImages.setOnClickListener(this);
        postImages.setOnClickListener(this);
     }


    //Show hide select button if images are selected or deselected
    public void showSelectButton() {

        selectedItems = imagesAdapter.getCheckedItems();
        if (selectedItems.size() > 0) {
            if(selectedItems.size()<=5) {
                selectImages.setText(selectedItems.size() + "- Selected");
                postImages.setText("Post");
                selectImages.setVisibility(View.VISIBLE);
                postImages.setVisibility(View.VISIBLE);
            }else
            {
                selectImages.setText("Reached Max Number");
                postImages.setVisibility(View.GONE);
            }
            } else
            {
            selectImages.setVisibility(View.GONE);
            postImages.setVisibility(View.GONE);
            }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.selectImagesBtn:
                //When button is clicked then fill array with selected images
                ArrayList<String> selectedItems = imagesAdapter.getCheckedItems();
                //Send back result to MainActivity with selected images
                Intent intent = new Intent();
                intent.putExtra(PostCampaign.CustomGalleryIntentKey, selectedItems.toString());
                intent.putExtra("pos", pos);
                intent.putExtra("imageId",imageId);
                //Convert Array into string to pass data
                setResult(RESULT_OK, intent);//Set result OK
                finish();
                //finish activity
                break;
            case R.id.selectPostBtn:
                /*Toast.makeText(getApplicationContext(),"Posting Images",Toast.LENGTH_LONG).show();
               String connection = NetworkCheck.getConnectivityStatusString(getApplicationContext());
                //Toast.makeText(getActivity(),""+connection,Toast.LENGTH_LONG).show();
                if (!connection.equals("No Internet Connection")) {
                    executeuploadImage();
                }else
                {
                    Snackbar snackbar=Snackbar.make(relativeLayout, "No Internet Connection", Snackbar.LENGTH_INDEFINITE);
                    snackbar.getView().setBackgroundColor(Color.WHITE);
                    View snackbarView = snackbar.getView();
                    TextView textView = (TextView) snackbarView.findViewById(android.support.design.R.id.snackbar_text);
                    textView.setTextColor(Color.parseColor("#253545"));
                    snackbar.show();
                }*/
                break;
        }

    }
/*public void executeuploadImage()
{
   int size = selectedItems.size();
    AppPreferences appPreferences = new AppPreferences(getApplicationContext());

    for(int s=0;s<size;s++)
    {
ArrayList values = new ArrayList();
        values.add(Constants.IMAGE_UPLOAD+appPreferences.getCampaignerId());
        values.add(selectedItems.get(s));
        values.add(appPreferences.getTokenId());
        values.add(appPreferences.getSessionId());
        new ImageUploadAsyncTask().execute
                (values);

    }
}*/


}