package com.balarcsoft.easyfunding;

import android.os.Bundle;

/**
 * Created by BS-2 on 4/19/2016.
 */
public class DonatingFromBank extends BaseActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState)
    { super.onCreate(savedInstanceState);
      setContentView(R.layout.donatingfrombank);
    }
}
