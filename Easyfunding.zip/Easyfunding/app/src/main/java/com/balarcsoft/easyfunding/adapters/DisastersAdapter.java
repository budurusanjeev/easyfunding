package com.balarcsoft.easyfunding.adapters;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import com.balarcsoft.easyfunding.R;
import com.balarcsoft.easyfunding.SingleDisasterList;
import com.balarcsoft.easyfunding.models.DisasterModel;

import java.util.ArrayList;

/**
 * Created by BS-2 on 4/18/2016.
 */
public class DisastersAdapter extends RecyclerView
        .Adapter<DisastersAdapter
        .DataObjectHolder> {
    public Activity context;
    private ArrayList<DisasterModel> mDataset;

    public DisastersAdapter(ArrayList<DisasterModel> myDataset, Activity applicationContext) {
        this.mDataset = myDataset;
        this.context = applicationContext;

    }

    @Override
    public DataObjectHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.singledisasterrow, parent, false);

        DataObjectHolder dataObjectHolder = new DataObjectHolder(view);
        return dataObjectHolder;


    }

    @Override
    public void onBindViewHolder(final DisastersAdapter.DataObjectHolder holder, final int position) {
        //  disasterImage,disasterText

        holder.disasterText.setText(mDataset.get(position).getDisasterName());
        holder.disasterImage.setBackgroundResource(mDataset.get(position).getImageUrl());
        holder.disasterText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                context.startActivity(new Intent(context, SingleDisasterList.class));
            }
        });
        holder.disasterImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                context.startActivity(new Intent(context, SingleDisasterList.class));
            }
        });
        holder.cardview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                context.startActivity(new Intent(context, SingleDisasterList.class));
            }
        });
        animate(holder);
    }
    public void animate(RecyclerView.ViewHolder viewHolder) {
        final Animation animAnticipateOvershoot = AnimationUtils.loadAnimation(context, R.anim.anticipateovershoot_interpolator);
        viewHolder.itemView.setAnimation(animAnticipateOvershoot);
    }
    @Override
    public int getItemCount() {
        return mDataset.size();
    }


    public class DataObjectHolder extends RecyclerView.ViewHolder {
        public TextView disasterText;
        public ImageView disasterImage;
        public CardView cardview;

        public DataObjectHolder(View itemView) {
            super(itemView);
            disasterText = (TextView) itemView
                    .findViewById(R.id.disasterName);
            disasterImage = (ImageView) itemView.findViewById(R.id.disasterImage);
            cardview = (CardView) itemView.findViewById(R.id.cardView);

        }


    }
}
