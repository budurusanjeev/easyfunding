package com.balarcsoft.easyfunding;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.BottomSheetBehavior;
import android.support.design.widget.BottomSheetDialogFragment;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.Snackbar;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.JsonRequest;
import com.android.volley.toolbox.Volley;
import com.balarcsoft.easyfunding.adapters.EditCampaignerAdapter;
import com.balarcsoft.easyfunding.adapters.ImagePagerAdapter;
import com.balarcsoft.easyfunding.adapters.TutsPlusBottomSheetDialogFragment;
import com.balarcsoft.easyfunding.delete.DeleteAsyncTask;
import com.balarcsoft.easyfunding.get.GetAsyncTask;
import com.balarcsoft.easyfunding.models.UpdateCampaignModel;
import com.balarcsoft.easyfunding.network.NetworkCheck;
import com.balarcsoft.easyfunding.post.PostAsyncTaskToken;
import com.balarcsoft.easyfunding.utils.AppPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by BS-2 on 4/29/2016.
 */
public class EditCampaign extends BaseActivity {
    ArrayList<UpdateCampaignModel> updateCampaignArrayList;
    EditCampaignerAdapter mAdapter;
    TextView campaigntitle;
    RecyclerView recyclerView;
    EditText updateEdit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.campaignedit);
        Button submitUpdate = (Button) findViewById(R.id.submitUpdate);
        Button moreButton = (Button) findViewById(R.id.more);
        final LinearLayout linearLayout = (LinearLayout) findViewById(R.id.linearLayout);
        campaigntitle = (TextView) findViewById(R.id.campaigntitle);
        updateEdit  = (EditText) findViewById(R.id.updateEdit);
        String campaignId = getIntent().getExtras().getString("campaignerId");
        String campaignName = getIntent().getExtras().getString("campaignName");
        campaigntitle.setText(campaignName);
        moreButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BottomSheetDialogFragment bottomSheetDialogFragment = new TutsPlusBottomSheetDialogFragment();
                bottomSheetDialogFragment.show(getSupportFragmentManager(), bottomSheetDialogFragment.getTag());
            }
        });

        recyclerView = (RecyclerView) findViewById(R.id.commentList);

        // use this setting to improve performance if you know that changes
        // in content do not change the layout size of the RecyclerView
        recyclerView.setHasFixedSize(true);

        LinearLayoutManager mLayoutManager = new LinearLayoutManager(this);

        // use a linear layout manager
        recyclerView.setLayoutManager(mLayoutManager);
        updateCampaignArrayList = new ArrayList<UpdateCampaignModel>();

        String connection = NetworkCheck.getConnectivityStatusString(getApplicationContext());

        if (!connection.equals("No Internet Connection")) {
            sendRequest();

        } else {
            Snackbar snackbar = Snackbar.make(linearLayout, "No Internet Connection ", Snackbar.LENGTH_INDEFINITE);
            snackbar.getView().setBackgroundColor(Color.WHITE);
            View snackbarView = snackbar.getView();
            TextView textView = (TextView) snackbarView.findViewById(android.support.design.R.id.snackbar_text);
            textView.setTextColor(Color.parseColor("#0a6b58"));
            snackbar.show();
        }
        submitUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String connection = NetworkCheck.getConnectivityStatusString(getApplicationContext());

                if (!connection.equals("No Internet Connection")) {
                    if (!TextUtils.isEmpty(updateEdit.getText().toString())) {
                        sendPostRequest();
                        Log.v("submit","submit");
                    }
                } else {
                    Snackbar snackbar = Snackbar.make(linearLayout, "No Internet Connection ", Snackbar.LENGTH_INDEFINITE);
                    snackbar.getView().setBackgroundColor(Color.WHITE);
                    View snackbarView = snackbar.getView();
                    TextView textView = (TextView) snackbarView.findViewById(android.support.design.R.id.snackbar_text);
                    textView.setTextColor(Color.parseColor("#0a6b58"));
                    snackbar.show();
                }
            }
        });

    }

    private void sendPostRequest() {
        JSONObject jsonObjectUpdate = null;
        final AppPreferences appPreferences = new AppPreferences(getApplicationContext());
        String url = Constants.UPDATE_POST_URL;
        try {
            jsonObjectUpdate = new JSONObject();
            jsonObjectUpdate.put("campaignId", appPreferences.getCampaignerId());
            jsonObjectUpdate.put("profileId", appPreferences.getProfileId());
            jsonObjectUpdate.put("description", updateEdit.getText().toString());

            JsonObjectRequest stringRequest = new JsonObjectRequest(Request.Method.POST, url, jsonObjectUpdate, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {

                    try {
                        UpdateCampaignModel disasterModel = new UpdateCampaignModel();
                        DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
                        Date date = new Date();
                        disasterModel.setPostedDate(dateFormat.format(date));
                        disasterModel.setUpdatedComment(updateEdit.getText().toString());
                        mAdapter.add(0, disasterModel);
                        recyclerView.setAdapter(mAdapter);
                        updateEdit.setText("");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                    String body = null;
                    //get status code here
                    //   String statusCode = String.valueOf(error.networkResponse.statusCode);
                    //get response body and parse with appropriate encoding
                    if (error instanceof TimeoutError || error instanceof NoConnectionError)
                    {
                        Toast.makeText(getApplicationContext(), "ConnectionError",
                                Toast.LENGTH_LONG).show();
                    } else if (error instanceof ServerError)
                    {

                        Toast.makeText(getApplicationContext(), "ServerError",
                                Toast.LENGTH_LONG).show();
                    } else if (error instanceof NetworkError)
                    {
                        Toast.makeText(getApplicationContext(), "NetworkError",
                                Toast.LENGTH_LONG).show();

                    }else if (error.networkResponse.data != null) {
                        try {
                            body = new String(error.networkResponse.data, "UTF-8");
                            JSONObject failJsonObject = new JSONObject(body);
                            new android.app.AlertDialog.Builder(EditCampaign.this)
                                    .setMessage(failJsonObject.getString("message"))
                                    .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int which) {
                                            dialog.cancel();
                                        }
                                    })
                                    .show();
                        } catch (UnsupportedEncodingException e) {
                            e.printStackTrace();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                }
            }) {

                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("content-Type", "application/json");
                    params.put("Accept", "application/json");
                    return params;
                }

                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {

                    Map<String, String> params = new HashMap<String, String>();
                    params.put("Cookie", appPreferences.getSessionId().trim());
                    params.put("token", appPreferences.getTokenId().trim());
                    return params;
                }
            };
            RequestQueue requestQueue = Volley.newRequestQueue(this);
            requestQueue.add(stringRequest);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private void sendRequest() {

      final AppPreferences  appPreferences = new AppPreferences(getApplicationContext());
        String url = Constants.UPDATE_URL+appPreferences.getCampaignerId();
Log.v("url","url"+url);
        JsonArrayRequest stringRequest = new JsonArrayRequest(Request.Method.GET,url,new Response.Listener<JSONArray>()
        {
            @Override
            public void onResponse(JSONArray response) {

                try{
                    int len = response.length();
                    for (int s = 0; s < len; s++) {
                        JSONObject jsonObject = response.getJSONObject(s);
                        UpdateCampaignModel disasterModel = new UpdateCampaignModel();
                        disasterModel.setId(jsonObject.getString("id"));
                        disasterModel.setPostedDate(jsonObject.getString("updatedDate"));
                        disasterModel.setUpdatedComment(jsonObject.getString("description"));
                        updateCampaignArrayList.add(disasterModel);
                    }
                    mAdapter = new EditCampaignerAdapter(updateCampaignArrayList, EditCampaign.this);
                    recyclerView.setAdapter(mAdapter);
                }catch (Exception e )
                {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                if (error instanceof TimeoutError || error instanceof NoConnectionError)
                {
                    Toast.makeText(getApplicationContext(), "ConnectionError",
                            Toast.LENGTH_LONG).show();
                } else if (error instanceof ServerError)
                {

                    Toast.makeText(getApplicationContext(), "ServerError",
                            Toast.LENGTH_LONG).show();
                } else if (error instanceof NetworkError)
                {
                    Toast.makeText(getApplicationContext(), "NetworkError",
                            Toast.LENGTH_LONG).show();

                }
               else if(error.networkResponse.data!=null) {
                    String body= null;
                    //get status code here
                    //   String statusCode = String.valueOf(error.networkResponse.statusCode);
                    //get response body and parse with appropriate encoding
                    try {
                        body = new String(error.networkResponse.data,"UTF-8");
                        JSONObject failJsonObject = new JSONObject(body);
                        new android.app.AlertDialog.Builder(EditCampaign.this)
                                .setMessage(failJsonObject.getString("message"))
                                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.cancel();
                                    }
                                })
                                .show();
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

            }
        })
        {

            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("content-Type", "application/json");
                params.put("Accept", "application/json");
                return params;
            }

            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {

                Map<String, String>  params = new HashMap<String, String>();
                params.put("Cookie", appPreferences.getSessionId().trim());
                params.put("token", appPreferences.getTokenId().trim());
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    public void deleteUpdate(String postion)
    {
       if(postion!=null) {
           AppPreferences appPreferences = new AppPreferences(getApplicationContext());
           ArrayList arrayList = new ArrayList();
           arrayList.add(Constants.UPDATE_POST_URL);
           arrayList.add(postion);
           arrayList.add(appPreferences.getSessionId());
           arrayList.add(appPreferences.getTokenId());
           new DeleteAsyncTask() {
               @Override
               protected void onPostExecute(SignupResponse signupResponse) {
                   super.onPostExecute(signupResponse);
                   Log.v("delete", "delete" + signupResponse.getResponse() + " \t " + signupResponse.getResult());
                  // Toast.makeText(getApplicationContext(), "" + signupResponse.getResult(), Toast.LENGTH_LONG).show();
               }
           }.execute(arrayList);

       }
    }
}
