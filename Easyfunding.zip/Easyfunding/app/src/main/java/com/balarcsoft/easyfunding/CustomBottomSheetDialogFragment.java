package com.balarcsoft.easyfunding;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.BottomSheetDialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

/**
 * Created by BS-2 on 6/3/2016.
 */
public class CustomBottomSheetDialogFragment extends BottomSheetDialogFragment implements View.OnClickListener {


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.content_bottom_sheet, container, false);
        TextView textViewBusiness = (TextView)v.findViewById(R.id.business);
        TextView textViewCharity = (TextView)v.findViewById(R.id.charity);
        TextView textViewearth = (TextView)v.findViewById(R.id.earthQuake);
        TextView textVieweducation = (TextView)v.findViewById(R.id.education);
        TextView textViewFamily = (TextView)v.findViewById(R.id.family);
        TextView textViewFloods = (TextView)v.findViewById(R.id.floods);
        TextView textViewMemory = (TextView)v.findViewById(R.id.memory);
        TextView textViewPets = (TextView)v.findViewById(R.id.pets);
        TextView textViewTravel = (TextView)v.findViewById(R.id.travel);

        textViewBusiness.setOnClickListener(this);
        textViewCharity.setOnClickListener(this);
        textViewearth.setOnClickListener(this);
        textVieweducation.setOnClickListener(this);
        textViewFamily.setOnClickListener(this);
        textViewFloods.setOnClickListener(this);
        textViewMemory.setOnClickListener(this);
        textViewPets.setOnClickListener(this);
        textViewTravel.setOnClickListener(this);

        return v;
        //startActivity(new Intent(getActivity(),CommonCampaignsList.class).putExtra("category","latest"));
    }

    @Override
    public void onClick(View v)
    {
    switch (v.getId())
    {
        case R.id.business:
            startActivity(new Intent(getActivity(),CategoryCampaignList.class).putExtra("category","1"));
            break;
        case R.id.charity:
            startActivity(new Intent(getActivity(),CategoryCampaignList.class).putExtra("category","2"));
            break;
        case R.id.earthQuake:
            startActivity(new Intent(getActivity(),CategoryCampaignList.class).putExtra("category","3"));
            break;
        case R.id.education:
            startActivity(new Intent(getActivity(),CategoryCampaignList.class).putExtra("category","4"));
            break;
        case R.id.family:
            startActivity(new Intent(getActivity(),CategoryCampaignList.class).putExtra("category","5"));
            break;
        case R.id.floods:
            startActivity(new Intent(getActivity(),CategoryCampaignList.class).putExtra("category","6"));
            break;
        case R.id.memory:
            startActivity(new Intent(getActivity(),CategoryCampaignList.class).putExtra("category","7"));
            break;
        case R.id.pets:
            startActivity(new Intent(getActivity(),CategoryCampaignList.class).putExtra("category","8"));
        break;
        case R.id.travel:
            startActivity(new Intent(getActivity(),CategoryCampaignList.class).putExtra("category","9"));
            break;
    }
    }
}
