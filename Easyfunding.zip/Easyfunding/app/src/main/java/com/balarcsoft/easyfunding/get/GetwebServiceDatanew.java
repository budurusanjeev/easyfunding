package com.balarcsoft.easyfunding.get;

import android.util.Log;

import com.balarcsoft.easyfunding.SignupResponse;

import org.apache.commons.io.IOUtils;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

/**
 * Created by BS-2 on 4/26/2016.
 */
public class GetwebServiceDatanew {
    //public static String response;
    public static String response,responseCode;
    public static SignupResponse getWebServiceData(String apiUrl,String sessionId,String token) {
        URL url;
        try {
            url = new URL(apiUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Cookie", sessionId.trim());
            conn.setRequestProperty("token",token.trim());
            System.out.println("Response Code: " + conn.getResponseCode());
          //  InputStream in = new BufferedInputStream(conn.getInputStream());
         //   response   = IOUtils.toString(in, "UTF-8");
            int HttpResult =conn.getResponseCode();

            responseCode=String.valueOf(HttpResult);
            StringBuilder sb = new StringBuilder();

            if(HttpResult ==HttpURLConnection.HTTP_OK){

                BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(),"utf-8"));

                String line = null;

                while ((line = br.readLine()) != null) {
                    sb.append(line + "\n");
                }

                br.close();
                response=sb.toString();
                conn.getRequestMethod();
                Log.v("Post response success", "Post response success" + response);
            }
            else
            {
                BufferedReader br = new BufferedReader(new InputStreamReader(conn.getErrorStream(),"utf-8"));

                String line = null;

                while ((line = br.readLine()) != null) {
                    sb.append(line + "\n");
                }

                br.close();
                response=sb.toString();
                conn.getRequestMethod();
                Log.v("Post response failure", "Post response failure" + response);
            }


            System.out.println(response);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (ProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();

        }

        return new SignupResponse(responseCode,response);
    }

}
