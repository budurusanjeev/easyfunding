package com.balarcsoft.easyfunding;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputLayout;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.CardView;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.balarcsoft.easyfunding.get.GetAsyncTask;
import com.balarcsoft.easyfunding.models.ImageModel;
import com.balarcsoft.easyfunding.network.NetworkCheck;
import com.balarcsoft.easyfunding.post.ImageUploadAsyncTask;
import com.balarcsoft.easyfunding.post.PostAsyncTaskToken;
import com.balarcsoft.easyfunding.put.PutAsyncTaskToken;
import com.balarcsoft.easyfunding.utils.AppPreferences;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by BS-2 on 4/25/2016.
 */
public class PostCampaign extends BaseActivity implements View.OnClickListener {
    String category;
    int categoryPosition = 0;
    String expiryDate,modeEdit;
    LinearLayout linearLayout;
    private static final int CustomGallerySelectId = 1;
    public static final String CustomGalleryIntentKey = "ImageArray";
    AppPreferences appPreferences;
    Button raiseMySelf, raiseOthers, raiseCharity, raiseUsd, raiseAud, raiseInr;
    int selectedCurrency=1, selectedCampaign=1;
    List<String> selectedImages;
    TextInputLayout  campaignTitle,campaignLocation,campaignDescription,fundAmountText,videoUrl,fbUrl,gPlusUrl,twitterUrl;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.postcampaign);

        appPreferences = new AppPreferences(getApplicationContext());
        fundAmountText = (TextInputLayout) findViewById(R.id.input_layout_fund_Amount);
        raiseMySelf = (Button) findViewById(R.id.mySelf);
        raiseOthers = (Button) findViewById(R.id.others);
        raiseCharity = (Button) findViewById(R.id.charity);
        final EditText editAmount = (EditText) findViewById(R.id.input_fund_amount);
        raiseUsd = (Button) findViewById(R.id.usd);
        raiseAud = (Button) findViewById(R.id.aud);
        raiseInr = (Button) findViewById(R.id.inr);
        linearLayout = (LinearLayout) findViewById(R.id.linearLayout);
        raiseMySelf.setOnClickListener(this);
        raiseOthers.setOnClickListener(this);
        raiseCharity.setOnClickListener(this);
        raiseUsd.setOnClickListener(this);
        raiseAud.setOnClickListener(this);
        raiseInr.setOnClickListener(this);
        final Spinner spinnerCategory = (Spinner) findViewById(R.id.catogorySpinner);
        campaignTitle = (TextInputLayout) findViewById(R.id.input_layout_campaign_title);
        campaignLocation = (TextInputLayout) findViewById(R.id.input_layout_campaign_location);
        campaignDescription = (TextInputLayout) findViewById(R.id.input_layout_campaign_description);

        videoUrl = (TextInputLayout) findViewById(R.id.input_layout_videourl);
        fbUrl = (TextInputLayout) findViewById(R.id.input_layout_fbpage);
        twitterUrl = (TextInputLayout) findViewById(R.id.input_layout_twitterpage);
        gPlusUrl = (TextInputLayout) findViewById(R.id.input_layout_google);


        final EditText editCampaignTitle = (EditText) findViewById(R.id.input_campaign_title);
        final EditText editCampaignLocation = (EditText) findViewById(R.id.input_campaign_location);
        final EditText  editCampaignDescription = (EditText) findViewById(R.id.input_campaign_description);
        final Button buttonExpiry = (Button) findViewById(R.id.campaignExpiry);
        final Button uploadImagesHere = (Button) findViewById(R.id.uploadImagesButton);
        final Button buttonPost = (Button) findViewById(R.id.postCampaign);
        modeEdit=appPreferences.getMode();
        if (appPreferences.getMode().equals("edit")) {
            AppPreferences  appPreferences = new AppPreferences(getApplicationContext());
                String connection = NetworkCheck.getConnectivityStatusString(getApplicationContext());
                if (!connection.equals("No Internet Connection")) {
                    ArrayList arrayList = new ArrayList();
                    arrayList.add(Constants.SINGLE_CAMPAIGNER);
                    arrayList.add(appPreferences.getCampaignerId());
                    arrayList.add(appPreferences.getSessionId());
                    arrayList.add(appPreferences.getTokenId());

                    new GetAsyncTask() {
                        ProgressDialog progressDialog;
                        @Override
                        protected void onPreExecute() {
                            super.onPreExecute();
                            progressDialog  = new ProgressDialog(PostCampaign.this);
                            progressDialog.setIndeterminate(true);
                            progressDialog.setMessage("Please wait");
                        }
                        @Override
                        protected void onPostExecute(SignupResponse signupResponse) {
                            super.onPostExecute(signupResponse);

                            progressDialog.dismiss();
                            if (signupResponse.getResponse() != null) {
                                if (signupResponse.getResponse().equals("200")) {
                            ArrayList<ImageModel> imageModels = new ArrayList<ImageModel>();
                                    try {
                                        JSONObject jsonObject = new JSONObject(signupResponse.getResult());
                                        editAmount.setText(jsonObject.getString("amount"));
                                        JSONObject reasonJobject = jsonObject.getJSONObject("reasonsDto");
                                        selectCurrencyCampaign(reasonJobject.getString("reason"));
                                        JSONObject currencyJobject = jsonObject.getJSONObject("currencyDto");
                                        selectCurrencyCampaign(currencyJobject.getString("currency"));
                                        editCampaignTitle.setText(jsonObject.getString("title"));
                                        editCampaignLocation.setText(jsonObject.getString("location"));
                                        editCampaignDescription.setText(jsonObject.getString("description"));
                                        JSONObject categoryJobject = jsonObject.getJSONObject("categoriesDto");
                                        categoryJobject.getInt("id");
                                        spinnerCategory.setSelection(categoryJobject.getInt("id"));
                                        JSONObject jsonObjectdate = new JSONObject(signupResponse.getResult());
                                        buttonExpiry.setText(jsonObjectdate.getString("expiryDate"));
                                        expiryDate= jsonObjectdate.getString("expiryDate");
                                        JSONArray jsonArray = jsonObject.getJSONArray("images");
                                        if(jsonArray.length()>0) {
                                            for (int a = 0; a < jsonArray.length(); a++) {
                                                JSONObject imageObject = jsonArray.getJSONObject(a);
                                                ImageModel imageModel = new ImageModel();
                                                imageModel.setCampaignId(imageObject.getString("id"));
                                                imageModel.setImageUrl(imageObject.getString("imageUrl"));
                                                imageModels.add(imageModel);
                                            Log.v("imageUrl","imageUrl"+imageObject.getString("imageUrl"));
                                            }
                                        }
                                        loadImages(imageModels);
                                        Log.v("getCampaigner", "getCampaigner" + reasonJobject.getString("reason") + "\t" + currencyJobject.getString("currency"));

                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }

                                } else {
                                    try {
                                        JSONObject loginFail = new JSONObject(signupResponse.getResult());
                                        Toast.makeText(getApplicationContext(), "" + loginFail.getString("message"), Toast.LENGTH_LONG).show();
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }
                            } else {
                                Toast.makeText(getApplicationContext(), "Due to network issue unable to connect to server", Toast.LENGTH_LONG).show();
                            }
                        }
                    }.execute(arrayList);
                } else {
                    Snackbar snackbar = Snackbar.make(linearLayout, "No Internet Connection", Snackbar.LENGTH_INDEFINITE);
                    snackbar.getView().setBackgroundColor(Color.WHITE);
                    View snackbarView = snackbar.getView();
                    TextView textView = (TextView) snackbarView.findViewById(android.support.design.R.id.snackbar_text);
                    textView.setTextColor(Color.parseColor("#0a6b58"));
                    snackbar.show();
                }

        }

        String categories[] = new String[]{"Pick a category","Business","Charity","Earth quake",
                                           "Education","Family","Floods","Memory","Pets","Travel" };
        ArrayAdapter<String> categoryArrayAdapter = new ArrayAdapter<String>(PostCampaign.this, android.R.layout.simple_dropdown_item_1line, categories);
        spinnerCategory.setAdapter(categoryArrayAdapter);
        spinnerCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                category = parent.getItemAtPosition(position).toString();
                categoryPosition = position;
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    uploadImagesHere.setOnClickListener(new View.OnClickListener()

    {
        @Override
        public void onClick (View v){
        startActivityForResult(new Intent(getApplicationContext(), CustomGallery_Activity.class).putExtra("pos","no"), CustomGallerySelectId);
    }
    });

        buttonExpiry.setOnClickListener(new View.OnClickListener()

                                        {
                                            @Override
                                            public void onClick (View v){

                                                final AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(PostCampaign.this);
                                                LayoutInflater inflater = getLayoutInflater();
                                                View dialogView = inflater.inflate(R.layout.custom_date_alert, null);
                                                dialogBuilder.setView(dialogView);
                                                final AlertDialog alertDialog = dialogBuilder.create();
                                                alertDialog.show();
                                                final DatePicker date = (DatePicker) dialogView.findViewById(R.id.datePicker);
                                                date.setMinDate(Calendar.getInstance().getTimeInMillis() - 1000);
                                                Button ok = (Button) dialogView.findViewById(R.id.button_ok);
                                                Button cancel = (Button) dialogView.findViewById(R.id.button_cancel);
                                                cancel.setOnClickListener(new View.OnClickListener() {
                                                    @Override
                                                    public void onClick(View v) {
                                                        alertDialog.dismiss();
                                                    }
                                                });
                                                ok.setOnClickListener(new View.OnClickListener() {
                                                    @Override
                                                    public void onClick(View v) {
                                                        buttonExpiry.setText(date.
                                                                getYear() + "-" + String.valueOf(date.getMonth() + 1) + "-" + date.getDayOfMonth());
                                                        expiryDate = date.
                                                                getYear() + "-" + String.valueOf(date.getMonth() + 1) + "-" + date.getDayOfMonth();
                                                        alertDialog.dismiss();
                                                    }
                                                });

                                            }
                                        });

    buttonPost.setOnClickListener(new View.OnClickListener()
    {
        @Override
        public void onClick (View v){
        String connection = NetworkCheck.getConnectivityStatusString(getApplicationContext());

        if (!connection.equals("No Internet Connection")) {
                if (modeEdit.equals("edit")) {
                    try {

                        sendEditRequest();

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {

                    try {
                        if (!TextUtils.isEmpty(fundAmountText.getEditText().getText().toString())&&!TextUtils.isEmpty(campaignTitle.getEditText().getText().toString()) &&
                                !TextUtils.isEmpty(campaignLocation.getEditText().getText().toString()) &&
                                !TextUtils.isEmpty(campaignDescription.getEditText().getText().toString()) &&
                                !category.equals("Pick a category")&&!TextUtils.isEmpty(expiryDate))
                        {
                            try {
                                sendRequest();
                                campaignTitle.setError(null);
                                campaignTitle.setErrorEnabled(false);
                                campaignLocation.setError(null);
                                campaignLocation.setErrorEnabled(false);
                                campaignDescription.setError(null);
                                campaignDescription.setErrorEnabled(false);
                                fundAmountText.setError(null);
                                fundAmountText.setErrorEnabled(false);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        } else {

                           if(TextUtils.isEmpty(fundAmountText.getEditText().getText().toString())) {
                               fundAmountText.setError("Fund amount is missing");
                               fundAmountText.setErrorEnabled(true);
                               Toast.makeText(getApplicationContext(),"Fund amount is missing",Toast.LENGTH_LONG).show();
                           }else
                           {
                               fundAmountText.setError(null);
                               fundAmountText.setErrorEnabled(false);
                           }
                            if (category.equals("Pick category")) {
                                Toast.makeText(getApplicationContext(), "Select a category", Toast.LENGTH_LONG).show();
                            }
                            if (!TextUtils.isEmpty(campaignTitle.getEditText().getText().toString())) {
                                campaignTitle.setError(null);
                                campaignTitle.setErrorEnabled(false);
                            } else {
                                campaignTitle.setError("Campaign Title is missing");
                                campaignTitle.setErrorEnabled(true);
                                Toast.makeText(getApplicationContext(),"Campaign Title is missing",Toast.LENGTH_LONG).show();
                            }
                            if (!TextUtils.isEmpty(campaignLocation.getEditText().getText().toString())) {
                                campaignLocation.setError(null);
                                campaignLocation.setErrorEnabled(false);
                            } else {
                                campaignLocation.setError("Campaign Location is missing");
                                campaignLocation.setErrorEnabled(true);
                                Toast.makeText(getApplicationContext(),"Campaign Location is missing",Toast.LENGTH_LONG).show();
                            }
                            if (!TextUtils.isEmpty(campaignDescription.getEditText().getText().toString())) {
                                campaignDescription.setError(null);
                                campaignDescription.setErrorEnabled(false);
                            } else {
                                campaignDescription.setError("Campaign Description is missing");
                                campaignDescription.setErrorEnabled(true);
                                Toast.makeText(getApplicationContext(),"Campaign Description is missing",Toast.LENGTH_LONG).show();
                            }
                            if (TextUtils.isEmpty(expiryDate))
                            {
                                Toast.makeText(getApplicationContext(),"Select the expiry date",Toast.LENGTH_LONG).show();
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
        } else {
            Snackbar snackbar = Snackbar.make(linearLayout, "No Internet Connection", Snackbar.LENGTH_INDEFINITE);
            snackbar.getView().setBackgroundColor(Color.WHITE);
            View snackbarView = snackbar.getView();
            TextView textView = (TextView) snackbarView.findViewById(android.support.design.R.id.snackbar_text);
            textView.setTextColor(Color.parseColor("#253545"));
            snackbar.show();
        }
    }
    });


}

    private void sendEditRequest() {
        JSONObject jsonObject = new JSONObject();
        final AppPreferences appPreferences = new AppPreferences(getApplicationContext());
        try {

            jsonObject.put("amount", BigDecimal.valueOf(Double.valueOf(fundAmountText.getEditText().getText().toString())));
            jsonObject.put("createdBy", Integer.parseInt(appPreferences.getProfileId()));

            JSONObject jsonObjectCurrency = new JSONObject();
            jsonObjectCurrency.put("id", selectedCurrency);
            jsonObject.put("currencyDto", jsonObjectCurrency);

            JSONObject jsonObjectReason = new JSONObject();
            jsonObjectReason.put("id", selectedCampaign);
            jsonObject.put("reasonsDto", jsonObjectReason);
                                /*
                                * Campaign
                                * */
            jsonObject.put("title", campaignTitle.getEditText().getText().toString());
            jsonObject.put("location", campaignLocation.getEditText().getText().toString());
            jsonObject.put("description", campaignDescription.getEditText().getText().toString());

            jsonObject.put("youtubeUrl", videoUrl.getEditText().getText().toString());
            jsonObject.put("facebookUrl", fbUrl.getEditText().getText().toString());
            jsonObject.put("googleUrl", gPlusUrl.getEditText().getText().toString());
            jsonObject.put("twitterUrl", twitterUrl.getEditText().getText().toString());

            JSONObject jsonObjectCategory = new JSONObject();
            jsonObjectCategory.put("id", categoryPosition);
            jsonObject.put("categoriesDto", jsonObjectCategory);

            JSONObject jsonObjectthemes = new JSONObject();
            jsonObjectthemes.put("id", 2);
            jsonObject.put("themesDto", jsonObjectthemes);
            jsonObject.put("id", Integer.parseInt(appPreferences.getCampaignerId()));
            jsonObject.put("expiryDate", expiryDate);
            Log.v("json", "json  " + jsonObject.toString());
        }catch (Exception e)
        {
            e.printStackTrace();
        }
        String url = Constants.EDIT_SINGLE_CAMPAIGNER;

        JsonObjectRequest stringRequest = new JsonObjectRequest(Request.Method.PUT,url,jsonObject,new Response.Listener<JSONObject>()
        {
            @Override
            public void onResponse(JSONObject response) {

                Toast.makeText(getApplicationContext(), "Edit Campaign Successfully "+response, Toast.LENGTH_LONG).show();
                try{
                    if (selectedImages != null) {
                        final AppPreferences appPreferences = new AppPreferences(getApplicationContext());
                        for (int s = 0; s < selectedImages.size(); s++) {
                            ArrayList values = new ArrayList();
                            values.add(Constants.IMAGE_UPLOAD + response.getString("id"));
                            values.add(selectedImages.get(s));
                            values.add("");
                            values.add(appPreferences.getTokenId());
                            values.add(appPreferences.getSessionId());
                            new ImageUploadAsyncTask() {
                                @Override
                                protected void onPostExecute(SignupResponse signupResponse) {
                                    super.onPostExecute(signupResponse);
                                    Log.v("image response", "image response" + signupResponse.getResponse());
                                    Toast.makeText(getApplicationContext(), "Images uploaded Successfully ", Toast.LENGTH_LONG).show();
                                }
                            }.execute
                                    (values);

                        }

                    }
                    Intent i = new Intent(getApplicationContext(), MyCampaign.class);
                    i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(i);
                }catch (Exception e )
                {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                String body= null;
                //get status code here
                //   String statusCode = String.valueOf(error.networkResponse.statusCode);
                //get response body and parse with appropriate encoding
                if(error.networkResponse.data!=null) {
                    try {
                        body = new String(error.networkResponse.data,"UTF-8");
                        Log.v("error","error  "+body);
                        Log.v("error","error  "+body);
                        JSONObject failJsonObject = new JSONObject(body);
                        new android.app.AlertDialog.Builder(PostCampaign.this)
                                .setMessage(failJsonObject.getString("message"))
                                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.cancel();
                                    }
                                })
                                .show();
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

            }
        })
        {

            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("content-Type", "application/json");
                params.put("Accept", "application/json");
                return params;
            }

            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("Cookie", appPreferences.getSessionId().trim());
                params.put("token", appPreferences.getTokenId().trim());
                Log.v("token", "token   " + appPreferences.getTokenId());
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    private void sendRequest()
    {
        final AppPreferences appPreferences = new AppPreferences(getApplicationContext());
        JSONObject jsonObject = new JSONObject();
        try {



            jsonObject.put("amount", BigDecimal.valueOf(Double.valueOf(fundAmountText.getEditText().getText().toString())));
            jsonObject.put("createdBy", Integer.parseInt(appPreferences.getProfileId()));

            JSONObject jsonObjectCurrency = new JSONObject();
            jsonObjectCurrency.put("id", selectedCurrency);
            jsonObject.put("currencyDto", jsonObjectCurrency);

            JSONObject jsonObjectReason = new JSONObject();
            jsonObjectReason.put("id", selectedCampaign);
            jsonObject.put("reasonsDto", jsonObjectReason);
                                /*
                                * Campaign
                                * */
            /*
            "youtubeUrl": "www.youtube.com/djkfdfbnbnjhbdf",
                    "facebookUrl": "www.facebook.com/duyhgbfg",
                    "googleUrl": "www.plus.google.com/djgbjhdf",
                    "twitterUrl": "www.twitter.com/dgbj",*/
            jsonObject.put("youtubeUrl", videoUrl.getEditText().getText().toString());
            jsonObject.put("facebookUrl", fbUrl.getEditText().getText().toString());
            jsonObject.put("googleUrl", gPlusUrl.getEditText().getText().toString());
            jsonObject.put("twitterUrl", twitterUrl.getEditText().getText().toString());

            jsonObject.put("title", campaignTitle.getEditText().getText().toString());
            jsonObject.put("location", campaignLocation.getEditText().getText().toString());
            jsonObject.put("description", campaignDescription.getEditText().getText().toString());

            JSONObject jsonObjectCategory = new JSONObject();
            jsonObjectCategory.put("id", categoryPosition);
            jsonObject.put("categoriesDto", jsonObjectCategory);

            JSONObject jsonObjectthemes = new JSONObject();
            jsonObjectthemes.put("id", 2);
            jsonObject.put("themesDto", jsonObjectthemes);

                                /*
                                * Library
                                * */
            jsonObject.put("expiryDate", expiryDate);
            Log.v("json", "json  " + jsonObject.toString());
        }catch (Exception e)
        {
            e.printStackTrace();
        }
        String url = Constants.POST_CAMPAIGN;

        JsonObjectRequest stringRequest = new JsonObjectRequest(Request.Method.POST,url,jsonObject,new Response.Listener<JSONObject>()
        {
            @Override
            public void onResponse(JSONObject response) {

                Toast.makeText(getApplicationContext(), "Posted Campaign Successfully "+response, Toast.LENGTH_LONG).show();
            try{
                if (selectedImages != null) {
                    final AppPreferences appPreferences = new AppPreferences(getApplicationContext());
                    for (int s = 0; s < selectedImages.size(); s++) {
                        ArrayList values = new ArrayList();
                        values.add(Constants.IMAGE_UPLOAD + response.getString("id"));
                        values.add(selectedImages.get(s));
                        values.add("");
                        values.add(appPreferences.getTokenId());
                        values.add(appPreferences.getSessionId());
                        new ImageUploadAsyncTask() {
                            @Override
                            protected void onPostExecute(SignupResponse signupResponse) {
                                super.onPostExecute(signupResponse);
                                Log.v("image response", "image response" + signupResponse.getResponse());
                                Toast.makeText(getApplicationContext(), "Images uploaded Successfully ", Toast.LENGTH_LONG).show();
                            }
                        }.execute
                                (values);

                    }

                }
                Intent i = new Intent(getApplicationContext(), MyCampaign.class);
                i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(i);
            }catch (Exception e )
            {
            e.printStackTrace();
            }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                String body= null;
                //get status code here
                //   String statusCode = String.valueOf(error.networkResponse.statusCode);
                //get response body and parse with appropriate encoding
                if(error.networkResponse.data!=null) {
                    try {
                        body = new String(error.networkResponse.data,"UTF-8");
                        Log.v("error","error  "+body);
                        Log.v("error","error  "+body);
                        JSONObject failJsonObject = new JSONObject(body);
                        new android.app.AlertDialog.Builder(PostCampaign.this)
                                .setMessage(failJsonObject.getString("message"))
                                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.cancel();
                                    }
                                })
                                .show();
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

            }
        })
        {

            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("content-Type", "application/json");
                params.put("Accept", "application/json");
                return params;
            }

            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                final AppPreferences  appPreferences = new AppPreferences(getApplicationContext());
                Map<String, String>  params = new HashMap<String, String>();
                params.put("Cookie", appPreferences.getSessionId().trim());
                params.put("token", appPreferences.getTokenId().trim());
                Log.v("token","token"+appPreferences.getTokenId());
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.mySelf:
                selectedCampaign = 1;
                raiseMySelf.setBackgroundColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
                raiseMySelf.setTextColor(ContextCompat.getColor(getApplicationContext(), android.R.color.white));
                raiseOthers.setBackgroundResource(R.drawable.edittext_border);
                raiseOthers.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
                raiseCharity.setBackgroundResource(R.drawable.edittext_border);
                raiseCharity.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
                break;
            case R.id.others:
                selectedCampaign = 2;
                raiseOthers.setBackgroundColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
                raiseOthers.setTextColor(ContextCompat.getColor(getApplicationContext(), android.R.color.white));
                raiseMySelf.setBackgroundResource(R.drawable.edittext_border);
                raiseMySelf.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
                raiseCharity.setBackgroundResource(R.drawable.edittext_border);
                raiseCharity.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
                break;
            case R.id.charity:
                selectedCampaign = 3;
                raiseCharity.setBackgroundColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
                raiseCharity.setTextColor(ContextCompat.getColor(getApplicationContext(), android.R.color.white));
                raiseMySelf.setBackgroundResource(R.drawable.edittext_border);
                raiseMySelf.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
                raiseOthers.setBackgroundResource(R.drawable.edittext_border);
                raiseOthers.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
                break;
            case R.id.usd:
                selectedCurrency = 1;
                raiseUsd.setBackgroundColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
                raiseUsd.setTextColor(ContextCompat.getColor(getApplicationContext(), android.R.color.white));
                raiseAud.setBackgroundResource(R.drawable.edittext_border);
                raiseAud.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
                raiseInr.setBackgroundResource(R.drawable.edittext_border);
                raiseInr.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
                break;
            case R.id.aud:
                selectedCurrency = 2;
                raiseAud.setBackgroundColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
                raiseAud.setTextColor(ContextCompat.getColor(getApplicationContext(), android.R.color.white));
                raiseUsd.setBackgroundResource(R.drawable.edittext_border);
                raiseUsd.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
                raiseInr.setBackgroundResource(R.drawable.edittext_border);
                raiseInr.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
                break;
            case R.id.inr:
                selectedCurrency = 3;
                raiseInr.setBackgroundColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
                raiseInr.setTextColor(ContextCompat.getColor(getApplicationContext(), android.R.color.white));
                raiseAud.setBackgroundResource(R.drawable.edittext_border);
                raiseAud.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
                raiseUsd.setBackgroundResource(R.drawable.edittext_border);
                raiseUsd.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
                break;

        }
    }

    public void selectCurrencyCampaign(String value) {
        switch (value) {
            case "Myself":
                selectedCampaign = 1;
                raiseMySelf.setBackgroundColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
                raiseMySelf.setTextColor(ContextCompat.getColor(getApplicationContext(), android.R.color.white));
                raiseOthers.setBackgroundResource(R.drawable.edittext_border);
                raiseOthers.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
                raiseCharity.setBackgroundResource(R.drawable.edittext_border);
                raiseCharity.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
                break;
            case "Others":
                selectedCampaign = 2;
                raiseOthers.setBackgroundColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
                raiseOthers.setTextColor(ContextCompat.getColor(getApplicationContext(), android.R.color.white));
                raiseMySelf.setBackgroundResource(R.drawable.edittext_border);
                raiseMySelf.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
                raiseCharity.setBackgroundResource(R.drawable.edittext_border);
                raiseCharity.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
                break;
            case "Charity":
                selectedCampaign = 3;
                raiseCharity.setBackgroundColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
                raiseCharity.setTextColor(ContextCompat.getColor(getApplicationContext(), android.R.color.white));
                raiseMySelf.setBackgroundResource(R.drawable.edittext_border);
                raiseMySelf.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
                raiseOthers.setBackgroundResource(R.drawable.edittext_border);
                raiseOthers.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
                break;
            case "USD":
                selectedCurrency = 1;
                raiseUsd.setBackgroundColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
                raiseUsd.setTextColor(ContextCompat.getColor(getApplicationContext(), android.R.color.white));
                raiseAud.setBackgroundResource(R.drawable.edittext_border);
                raiseAud.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
                raiseInr.setBackgroundResource(R.drawable.edittext_border);
                raiseInr.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
                break;
            case "AUD":
                selectedCurrency = 2;
                raiseAud.setBackgroundColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
                raiseAud.setTextColor(ContextCompat.getColor(getApplicationContext(), android.R.color.white));
                raiseUsd.setBackgroundResource(R.drawable.edittext_border);
                raiseUsd.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
                raiseInr.setBackgroundResource(R.drawable.edittext_border);
                raiseInr.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
                break;
            case "INR":
                selectedCurrency = 3;
                raiseInr.setBackgroundColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
                raiseInr.setTextColor(ContextCompat.getColor(getApplicationContext(), android.R.color.white));
                raiseAud.setBackgroundResource(R.drawable.edittext_border);
                raiseAud.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
                raiseUsd.setBackgroundResource(R.drawable.edittext_border);
                raiseUsd.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
                break;

        }
    }
    protected void onActivityResult(int requestcode, int resultcode,
                                    Intent imagereturnintent) {
        super.onActivityResult(requestcode, resultcode, imagereturnintent);
        switch (requestcode) {
            case CustomGallerySelectId:
                if (resultcode == RESULT_OK) {
                    String imagesArray = imagereturnintent.getStringExtra(CustomGalleryIntentKey);
                    String pos= imagereturnintent.getStringExtra("pos");
                    String imageId=imagereturnintent.getStringExtra("imageId");//get Intent data
                    //Convert string array into List by splitting by ',' and substring after '[' and before ']'
                    selectedImages = Arrays.asList(imagesArray.substring(1, imagesArray.length() - 1).split(", "));

                    switch (pos)
                    {
                        case "no" :  loadGridView(new ArrayList<String>(selectedImages));
                                     break;
                        case "0":    loadAtPos(new ArrayList<String>(selectedImages), pos,imageId);
                                    break;
                        case "1":    loadAtPos(new ArrayList<String>(selectedImages),pos,imageId);
                            break;
                        case "3":    loadAtPos(new ArrayList<String>(selectedImages),pos,imageId);
                            break;
                        case "4":    loadAtPos(new ArrayList<String>(selectedImages),pos,imageId);
                            break;
                        case "2":    loadAtPos(new ArrayList<String>(selectedImages),pos,imageId);
                            break;

                    }
                    //call load gridview method by passing converted list into arrayList
                }
                break;

        }
    }

    private void loadAtPos(ArrayList<String> imagesArray,String pos,String imageId) {
        ImageView imageViewOne = (ImageView) findViewById(R.id.country_photo1);
        ImageView imageViewTwo = (ImageView) findViewById(R.id.country_photo2);
        ImageView imageViewThree = (ImageView) findViewById(R.id.country_photo3);
        ImageView imageViewFour = (ImageView) findViewById(R.id.country_photo4);
        ImageView imageViewFive = (ImageView) findViewById(R.id.country_photo5);
        DisplayImageOptions   options = new DisplayImageOptions.Builder()
                .cacheInMemory(true)
                .resetViewBeforeLoading(true).cacheOnDisk(true)
                .considerExifParams(true).bitmapConfig(Bitmap.Config.RGB_565)
                .build();
        ArrayList values;
            switch (pos)
            {
                //Load Images over ImageView

                case "0":  ImageLoader.getInstance().displayImage("file://" + imagesArray.get(0), imageViewOne, options);
                    values  = new ArrayList();
                    values.add(Constants.IMAGE_UPLOAD+appPreferences.getCampaignerId());
                    values.add(imagesArray.get(0));
                    values.add(imageId);
                    values.add(appPreferences.getTokenId());
                    values.add(appPreferences.getSessionId());
                    new ImageUploadAsyncTask()
                    {
                        @Override
                        protected void onPostExecute(SignupResponse signupResponse) {
                            super.onPostExecute(signupResponse);
                        Log.v("", "" + signupResponse.getResult() + "  " + signupResponse.getResponse());
                            Toast.makeText(getApplicationContext()," "+signupResponse.getResponse(),Toast.LENGTH_LONG).show();
                        }
                    }.execute
                            (values);
                    break;
                case "1":  ImageLoader.getInstance().displayImage("file://" + imagesArray.get(0), imageViewTwo, options);
                    values = new ArrayList();
                    values.add(Constants.IMAGE_UPLOAD+appPreferences.getCampaignerId());
                    values.add(imagesArray.get(0));
                    values.add(imageId);
                    values.add(appPreferences.getTokenId());
                    values.add(appPreferences.getSessionId());
                    new ImageUploadAsyncTask().execute
                            (values);
                    break;
                case "2":  ImageLoader.getInstance().displayImage("file://" + imagesArray.get(0), imageViewThree, options);
                    values = new ArrayList();
                    values.add(Constants.IMAGE_UPLOAD+appPreferences.getCampaignerId());
                    values.add(imagesArray.get(0));
                    values.add(imageId);
                    values.add(appPreferences.getTokenId());
                    values.add(appPreferences.getSessionId());
                    new ImageUploadAsyncTask().execute
                            (values);
                    break;
                case "3":  ImageLoader.getInstance().displayImage("file://" + imagesArray.get(0), imageViewFour, options);
                    values = new ArrayList();
                    values.add(Constants.IMAGE_UPLOAD+appPreferences.getCampaignerId());
                    values.add(imagesArray.get(0));
                    values.add(imageId);
                    values.add(appPreferences.getTokenId());
                    values.add(appPreferences.getSessionId());
                    new ImageUploadAsyncTask().execute
                            (values);
                    break;
                case "4":  ImageLoader.getInstance().displayImage("file://" + imagesArray.get(0), imageViewFive, options);
                    values = new ArrayList();
                    values.add(Constants.IMAGE_UPLOAD+appPreferences.getCampaignerId());
                    values.add(imagesArray.get(0));
                    values.add(imageId);
                    values.add(appPreferences.getTokenId());
                    values.add(appPreferences.getSessionId());
                    new ImageUploadAsyncTask().execute
                            (values);
                    break;
            }
    }




    //Load GridView
    private void loadGridView(ArrayList<String> imagesArray) {
        ImageView imageViewOne = (ImageView) findViewById(R.id.country_photo1);
        ImageView imageViewTwo = (ImageView) findViewById(R.id.country_photo2);
        ImageView imageViewThree = (ImageView) findViewById(R.id.country_photo3);
        ImageView imageViewFour = (ImageView) findViewById(R.id.country_photo4);
        ImageView imageViewFive = (ImageView) findViewById(R.id.country_photo5);
        DisplayImageOptions   options = new DisplayImageOptions.Builder()
                .cacheInMemory(true)
                .resetViewBeforeLoading(true).cacheOnDisk(true)
                .considerExifParams(true).bitmapConfig(Bitmap.Config.RGB_565)
                .build();
        int len = imagesArray.size();
        for(int s= 0; s<len; s++)
        {
switch (s)
{
    //Load Images over ImageView

    case 0:  ImageLoader.getInstance().displayImage("file://" + imagesArray.get(s), imageViewOne, options);
             break;
    case 1:  ImageLoader.getInstance().displayImage("file://" + imagesArray.get(s), imageViewTwo, options);
        break;
    case 2:  ImageLoader.getInstance().displayImage("file://" + imagesArray.get(s), imageViewThree, options);
        break;
    case 3:  ImageLoader.getInstance().displayImage("file://" + imagesArray.get(s), imageViewFour, options);
        break;
    case 4:  ImageLoader.getInstance().displayImage("file://" + imagesArray.get(s), imageViewFive, options);
        break;
}
        }

    }
    private void loadImages(final ArrayList<ImageModel> imagesArray)
    {
        final ImageView imageViewOne = (ImageView) findViewById(R.id.country_photo1);
        final ImageView imageViewTwo = (ImageView) findViewById(R.id.country_photo2);
        final ImageView imageViewThree = (ImageView) findViewById(R.id.country_photo3);
        final ImageView imageViewFour = (ImageView) findViewById(R.id.country_photo4);
        final ImageView imageViewFive = (ImageView) findViewById(R.id.country_photo5);

        DisplayImageOptions   options = new DisplayImageOptions.Builder()
                .cacheInMemory(true)
                .resetViewBeforeLoading(true).cacheOnDisk(true)
                .considerExifParams(true).bitmapConfig(Bitmap.Config.RGB_565)
                .build();
        Log.v("image","image size"+imagesArray.size());
        for(int s= 0; s<imagesArray.size(); s++)
        {
            switch (s)
            {

                case 0:  ImageLoader.getInstance().displayImage(imagesArray.get(0).getImageUrl(),imageViewOne,options);
                    break;
                case 1:  ImageLoader.getInstance().displayImage(imagesArray.get(1).getImageUrl(), imageViewTwo, options);
                    break;
                case 2:  ImageLoader.getInstance().displayImage(imagesArray.get(2).getImageUrl(), imageViewThree, options);
                    break;
                case 3:  ImageLoader.getInstance().displayImage(imagesArray.get(3).getImageUrl(), imageViewFour, options);
                    break;
                case 4:  ImageLoader.getInstance().displayImage(imagesArray.get(4).getImageUrl(), imageViewFive, options);
                    break;
            }
        }


        imageViewOne.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(imagesArray.size()>0)
                    {
                          startActivityForResult(new Intent(PostCampaign.this, CustomGallery_Activity.class).putExtra("pos", "0")
                            .putExtra("imageId", imagesArray.get(0).getCampaignId()), CustomGallerySelectId);
                    }
                    else
                    {
                        startActivityForResult(new Intent(PostCampaign.this, CustomGallery_Activity.class).putExtra("pos", "0")
                                .putExtra("imageId", ""), CustomGallerySelectId);
                    }
                }
            });


            imageViewTwo.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(imagesArray.size()>0)
                    {
                    startActivityForResult(new Intent(PostCampaign.this, CustomGallery_Activity.class).putExtra("pos","1")
                            .putExtra("imageId", imagesArray.get(1).getCampaignId()), CustomGallerySelectId);
                }
                else
                {
                    startActivityForResult(new Intent(PostCampaign.this, CustomGallery_Activity.class).putExtra("pos", "1")
                            .putExtra("imageId", ""), CustomGallerySelectId);
                }
                }
            });


            imageViewThree.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(imagesArray.size()>0)
                    {
                    startActivityForResult(new Intent(PostCampaign.this, CustomGallery_Activity.class).putExtra("pos","2")
                            .putExtra("imageId", imagesArray.get(2).getCampaignId()), CustomGallerySelectId);


                } else
                {
                    startActivityForResult(new Intent(PostCampaign.this, CustomGallery_Activity.class).putExtra("pos", "2")
                            .putExtra("imageId", ""), CustomGallerySelectId);

                 }
                }
            });





            imageViewFour.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(imagesArray.size()>0)
                    {
                    startActivityForResult(new Intent(PostCampaign.this, CustomGallery_Activity.class).putExtra("pos","3")
                            .putExtra("imageId", imagesArray.get(3).getCampaignId()), CustomGallerySelectId);
                    }else
                    {
                        startActivityForResult(new Intent(PostCampaign.this, CustomGallery_Activity.class).putExtra("pos", "3")
                                .putExtra("imageId", ""), CustomGallerySelectId);
                    }
                }
            });


            imageViewFive.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if(imagesArray.size()>0)
                    {   Toast.makeText(getApplicationContext()," true ",Toast.LENGTH_LONG).show();
                        startActivityForResult(new Intent(PostCampaign.this, CustomGallery_Activity.class).putExtra("pos", "4")
                                .putExtra("imageId", imagesArray.get(4).getCampaignId()), CustomGallerySelectId);
                    }else
                    {

                        startActivityForResult(new Intent(PostCampaign.this, CustomGallery_Activity.class).putExtra("pos", "4")
                                .putExtra("imageId", ""), CustomGallerySelectId);
                    }

                }
            });
    }

    @Override
    protected void onPause() {
        super.onPause();
    appPreferences.setMode("");
    }
}