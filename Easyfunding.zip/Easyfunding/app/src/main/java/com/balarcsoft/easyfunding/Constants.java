package com.balarcsoft.easyfunding;

/**
 * Created by BS-2 on 4/20/2016.
 */
public class Constants
{

    public static String host = "http://easyfunding-krishnasapps.rhcloud.com/";

    public static String SIGN_UP = host+"easyfunding/logon/registration";
    public static String SIGN_IN = host+"easyfunding/applogin/process";
    public static String POST_CAMPAIGN = host+"easyfunding/api/campaign/create";
    public static String GET_ALL_CAMPAIGNS = host+"easyfunding/api/campaign/bycampaigner/";
    public static String GET_CAMPAIGNER_DETAILS =  host+"easyfunding/api/profile/";
    public static String CHANGE_PASSWORD = host+"easyfunding/logon/changePassword";
    public static String FORGOT_PASSWORD = host+"easyfunding/logon/forgot/password";
    public static String ADD_DONATION = host+"easyfunding/api/donator/donation";
    public static String SINGLE_CAMPAIGNER = host+"easyfunding/api/campaign/single/";
    public static String EDIT_SINGLE_CAMPAIGNER = host+"easyfunding/api/campaign/campaignedit";
    public static String SEARCH_CAMPAIGNER = host+"easyfunding/api/campaign/searchby";
    public static String IMAGE_UPLOAD = host+"easyfunding/api/campaign/upload/image/";
    public static String UPDATE_URL = host+"easyfunding/api/campaign/updatesbycampaign/";
    public static String UPDATE_POST_URL = host+"easyfunding/api/campaign/updates";
    public static String SINGLE_CAMPAIGN = host+"easyfunding/api/campaign/single/";
    public static String DONATIONS_LIST = host+"easyfunding/api/donator/donationsbycampaign/";
    public static String SEARCH_CAMPAIGN =host+"easyfunding/api/campaign/search?campaignTitle=";
    public static String SINGLE_CAMPAIGN_VISIBILITY = host+"easyfunding/api/campaign/activeOrInActive/";
    public static String CAMPAIGN_CATEGORY  = host+"easyfunding/api/campaign/search?categoryId=";

}
