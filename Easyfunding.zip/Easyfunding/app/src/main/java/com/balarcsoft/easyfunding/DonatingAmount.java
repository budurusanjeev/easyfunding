package com.balarcsoft.easyfunding;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.design.widget.TextInputLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.balarcsoft.easyfunding.adapters.DisasterSingleAdapter;
import com.balarcsoft.easyfunding.models.SingleDisasterModel;
import com.balarcsoft.easyfunding.network.NetworkCheck;
import com.balarcsoft.easyfunding.post.PostAsyncTaskToken;
import com.balarcsoft.easyfunding.utils.AppPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by BS-2 on 4/19/2016.
 */
public class DonatingAmount extends BaseActivity{
    String paymentSelect,bankSelect,campaignId;
    TextInputLayout firstName,lastName,email,phone,donationAmount;
    Spinner   paymentType,bankSpinner;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.donatingamount);
         firstName = (TextInputLayout)findViewById(R.id.input_layout_donation_name);
         lastName = (TextInputLayout)findViewById(R.id.input_layout_donation_lastname);
         email = (TextInputLayout)findViewById(R.id.input_layout_donation_email);
         phone = (TextInputLayout)findViewById(R.id.input_layout_donation_phone);
         donationAmount = (TextInputLayout)findViewById(R.id.input_layout_donation_amount);
        paymentType = (Spinner)findViewById(R.id.paymentSpinner);
        bankSpinner = (Spinner)findViewById(R.id.accountSpinner);
        campaignId=getIntent().getExtras().getString("campaignId");
        Log.v("campign Id","campaignId "+campaignId);
        String paymentarray[] = new String[] {"Select Payment Type","Credit/Debit","NetBanking"};
        String bankarray[] =  new String[] {"Select Bank","Bank 1","Bank2","Bank3","Bank4","Bank5","Bank6"};

        ArrayAdapter<String> paymentAdapter = new ArrayAdapter<String>(DonatingAmount.this,android.R.layout.simple_dropdown_item_1line,paymentarray);
        ArrayAdapter<String> bankAdapter = new ArrayAdapter<String>(DonatingAmount.this,android.R.layout.simple_dropdown_item_1line,bankarray);
        paymentType.setAdapter(paymentAdapter);
        bankSpinner.setAdapter(bankAdapter);

        paymentType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                paymentSelect = parent.getItemAtPosition(position).toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        //bankSelect
        bankSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                bankSelect = parent.getItemAtPosition(position).toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        Button continueButton = (Button)findViewById(R.id.continueButton);
        continueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String connection = NetworkCheck.getConnectivityStatusString(getApplicationContext());

                if(!connection.equals("No Internet Connection"))
                {

                    if(!TextUtils.isEmpty(firstName.getEditText().getText().toString())
                        && !TextUtils.isEmpty(lastName.getEditText().getText().toString())
                        && !TextUtils.isEmpty(email.getEditText().getText().toString())
                        && !TextUtils.isEmpty(phone.getEditText().getText().toString())
                        && !TextUtils.isEmpty(donationAmount.getEditText().getText().toString())
                        && !(bankSelect.equals("Select Bank"))
                        && !(paymentSelect.equals("Select Payment Type")))
                    {

                        Log.v("bankSelect","bankSelect "+bankSelect);
                        Log.v("bankSelect", "bankSelect " + paymentSelect);
                        /*
                        * TODO need to go to payment gateway screen
                        * */

                        sendRequest();

                    }else
                    {
                        Log.v("bankSelect","bankSelect false"+bankSelect);
                        Log.v("bankSelect","bankSelect false"+paymentSelect);
                       // Toast.makeText(getApplicationContext(),"All False",Toast.LENGTH_LONG).show();
                        if(bankSelect.equals("Select Bank"))
                        {
                            Toast.makeText(getApplicationContext(),"Select a Bank",Toast.LENGTH_LONG).show();
                        }

                        if(paymentSelect.equals("Select Payment Type"))
                        {
                            Toast.makeText(getApplicationContext(),"Select a Banking type",Toast.LENGTH_LONG).show();
                        }

                        if(firstName.getEditText().getText().toString().equals("")) {
                            firstName.setErrorEnabled(true);
                            firstName.setError("Enter a first name");
                           
                        }else
                        {
                            firstName.setError(null);
                            firstName.setErrorEnabled(false);
                        }

                        if(lastName.getEditText().getText().toString().equals("")) {
                            lastName.setErrorEnabled(true);
                            lastName.setError("Enter a last name");

                        }else
                        {
                            lastName.setError(null);
                            lastName.setErrorEnabled(false);

                        }

                        if(phone.getEditText().getText().toString().equals("")) {
                            phone.setErrorEnabled(true);
                            phone.setError("Enter a Phone Number");

                        }else
                        {
                            phone.setError(null);
                            phone.setErrorEnabled(false);

                        }

                        if(donationAmount.getEditText().getText().toString().equals("")) {
                            donationAmount.setErrorEnabled(true);
                            donationAmount.setError("Enter a Donation Amount");

                        }else
                        {
                            donationAmount.setError(null);
                            donationAmount.setErrorEnabled(false);

                        }


                        if(!validateEmail(email.getEditText().getText().toString()))
                        {
                            email.setErrorEnabled(true);
                            email.setError("Not a valid Email address!");

                        }
                        else {
                            email.setError(null);
                            email.setErrorEnabled(false);

                        }
                    }
                }

            }
        });
    }

    private void sendRequest()  {
        JSONObject donationProfile= null;
        try {
            donationProfile = new JSONObject();
            donationProfile.put("firstName", firstName.getEditText().getText().toString());
            donationProfile.put("lastName", lastName.getEditText().getText().toString());
            donationProfile.put("userName", email.getEditText().getText().toString());
            donationProfile.put("phone", phone.getEditText().getText().toString());
            donationProfile.put("userType", "donator");
            donationProfile.put("gender", "male");
            JSONObject mainJson = new JSONObject();
            mainJson.put("amount", donationAmount.getEditText().getText().toString());
            mainJson.put("campaignId", campaignId);
            mainJson.put("type", "Online");
            mainJson.put("profileDto", donationProfile);

            final JsonObjectRequest jsonArrayRequest = new JsonObjectRequest(Constants.ADD_DONATION, mainJson ,new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response)
                {
                    Toast.makeText(getApplicationContext(),"Amount transferred successfully ",Toast.LENGTH_LONG).show();
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                    String body= null;
                    //get status code here

                    // String statusCode = String.valueOf(error.networkResponse.statusCode);

                    //get response body and parse with appropriate encoding

                        if (error instanceof TimeoutError || error instanceof NoConnectionError) {
                            Toast.makeText(getApplicationContext(), "ConnectionError",
                                    Toast.LENGTH_LONG).show();
                        } else if (error instanceof ServerError) {

                            Toast.makeText(getApplicationContext(), "ServerError",
                                    Toast.LENGTH_LONG).show();
                        } else if (error instanceof NetworkError) {
                            Toast.makeText(getApplicationContext(), "NetworkError",
                                    Toast.LENGTH_LONG).show();

                        }else if(error.networkResponse.data!=null) {
                        try {
                            body = new String(error.networkResponse.data, "UTF-8");

                            JSONObject failJsonObject = new JSONObject(body);
                            new android.app.AlertDialog.Builder(DonatingAmount.this)
                                    .setMessage(failJsonObject.getString("message"))
                                    .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int which) {
                                            dialog.cancel();
                                        }
                                    })
                                    .show();
                        } catch (UnsupportedEncodingException e) {
                            e.printStackTrace();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                }
            })
            {
                @Override
                protected Map<String, String> getParams()
                {
                    Map<String, String>  params = new HashMap<String, String>();
                    params.put("content-Type", "application/json");
                    params.put("Accept", "application/json");
                    return params;
                }

                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    final AppPreferences  appPreferences = new AppPreferences(getApplicationContext());
                    Map<String, String>  params = new HashMap<String, String>();
                    params.put("Cookie", appPreferences.getSessionId().trim());
                    params.put("token", appPreferences.getTokenId().trim());
                    return params;
                }
            };
            RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
            requestQueue.add(jsonArrayRequest);

        }catch (Exception e )
        {
            e.printStackTrace();
        }

    }

    public boolean validateEmail(String email) {
        final String EMAIL_PATTERN = "^[a-zA-Z0-9#_~!$&'()*+,;=:.\"(),:;<>@\\[\\]\\\\]+@[a-zA-Z0-9-]+(\\.[a-zA-Z0-9-]+)*$";
       Pattern pattern = Pattern.compile(EMAIL_PATTERN);
        Matcher matcher;
        matcher = pattern.matcher(email);
        return matcher.matches();
    }
}
