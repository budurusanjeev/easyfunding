package com.balarcsoft.easyfunding.adapters;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.support.v4.util.LruCache;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.android.volley.Cache;
import com.android.volley.Network;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.BasicNetwork;
import com.android.volley.toolbox.DiskBasedCache;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.NetworkImageView;
import com.balarcsoft.easyfunding.DetailDisaster;
import com.balarcsoft.easyfunding.R;
import com.balarcsoft.easyfunding.models.SingleDisasterModel;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;

import java.util.ArrayList;

/**
 * Created by BS-2 on 4/18/2016.
 */
public class DisasterSingleAdapter  extends RecyclerView
        .Adapter<DisasterSingleAdapter
        .DataObjectHolder>  {
    private ArrayList<SingleDisasterModel> mDataset;
    public Activity context;
    DisplayImageOptions options;

    @Override
    public DataObjectHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.disasterrow, parent, false);
        DataObjectHolder dataObjectHolder = new DataObjectHolder(view);
        return dataObjectHolder;
    }

    @Override
    public void onBindViewHolder(final DisasterSingleAdapter.DataObjectHolder holder, final int position)
    {
        holder.disasterText.setText(mDataset.get(position).getDisasterName());
        holder.disasterdDate.setText(mDataset.get(position).getDateCity());
        holder.disasterGoalAmount.setText(mDataset.get(position).getGoalAmount());
        if(!mDataset.get(position).getDonatedAmount().equals("null"))
        {
            holder.disasterDonatedAmount.setText(mDataset.get(position).getDonatedAmount());
        }else
        {
            holder.disasterDonatedAmount.setText("0.0");
        }
        ImageLoader.getInstance().displayImage(mDataset.get(position).getImageUrl(), holder.disasterImage, options, new ImageLoadingListener() {
            @Override
            public void onLoadingStarted(String imageUri, View view) {

                holder.progressBar.setVisibility(View.VISIBLE);
            }

            @Override
            public void onLoadingFailed(String imageUri, View view, FailReason failReason) {

            }

            @Override
            public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {

                //progressBar.dismiss();

                //loadedImage.compress(Bitmap.CompressFormat.PNG, 100);
                holder.progressBar.setVisibility(View.GONE);
                holder.disasterImage.setImageBitmap(loadedImage);
            }

            @Override
            public void onLoadingCancelled(String imageUri, View view) {
               // progressBar.dismiss();
                holder.progressBar.setVisibility(View.GONE);
            }
        });
        animate(holder);
        holder.disasterImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                context.startActivity(new Intent(context, DetailDisaster.class)
                        .putExtra("campaignId",mDataset.get(position).getId()));
            }
        });


        holder.disasterText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                context.startActivity(new Intent(context, DetailDisaster.class)
                        .putExtra("campaignId",mDataset.get(position).getId()));
            }
        });

        holder.cardview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                context.startActivity(new Intent(context, DetailDisaster.class)
                        .putExtra("campaignId",mDataset.get(position).getId()));
            }
        });

    }
    public void animate(RecyclerView.ViewHolder viewHolder) {
        final Animation animAnticipateOvershoot = AnimationUtils.loadAnimation(context, R.anim.bounce_interpolator);
        viewHolder.itemView.setAnimation(animAnticipateOvershoot);
    }
    @Override
    public int getItemCount() {
        return mDataset.size();
    }

    public void add(SingleDisasterModel string) {
        insert(string, mDataset.size());
    }

    public void insert(SingleDisasterModel string, int position) {

        mDataset.add(position, string);
        notifyItemInserted(position);
        //  Log.v("scrollsanjeev","scrollsanjeev"+string.getLink());

    }
    public class DataObjectHolder extends RecyclerView.ViewHolder {
        public TextView disasterText,disasterdDate,disasterGoalAmount,disasterDonatedAmount;
        public ImageView disasterImage;
        public CardView cardview;
        public ProgressBar progressBar;
        public DataObjectHolder(View itemView) {
            super(itemView);
            disasterText = (TextView) itemView
                    .findViewById(R.id.disasterName);
            disasterImage=(ImageView)itemView.findViewById(R.id.disasterImage);
            disasterdDate=(TextView) itemView
                    .findViewById(R.id.disasterTimeCity);
            disasterGoalAmount=(TextView) itemView
                    .findViewById(R.id.disasterGoal);
            disasterDonatedAmount=(TextView) itemView
                    .findViewById(R.id.disasterAmount);
            cardview=(CardView)itemView.findViewById(R.id.cardView);
            progressBar=(ProgressBar) itemView
                    .findViewById(R.id.progressBar);

        }
    }

    public DisasterSingleAdapter(ArrayList<SingleDisasterModel> myDataset, Activity applicationContext) {
        this.mDataset = myDataset;
        this.context=applicationContext;

        options = new DisplayImageOptions.Builder()
                .considerExifParams(true)
                .bitmapConfig(Bitmap.Config.RGB_565)
                .imageScaleType(ImageScaleType.IN_SAMPLE_INT)
                         .build();
    }


}
