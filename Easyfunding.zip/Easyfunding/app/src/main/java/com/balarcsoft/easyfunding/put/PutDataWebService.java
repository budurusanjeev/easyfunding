package com.balarcsoft.easyfunding.put;

import android.content.Context;
import android.util.Log;

import com.balarcsoft.easyfunding.SignupResponse;
import com.balarcsoft.easyfunding.utils.AppPreferences;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.MultipartBuilder;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

/**
 * Created by BS2 on 13-11-2015.
 */
public class PutDataWebService {

    public static String response,responseCode;
    private static final MediaType MEDIA_TYPE = MediaType.parse("image/*");


    public static SignupResponse putWebServiceData(JSONObject jobject, String url,String sessionId,String token) {
        URL object= null;
        try {
            object = new URL(url);
            HttpURLConnection con = (HttpURLConnection) object.openConnection();
            con.setDoOutput(true);
            con.setDoInput(true);
            con.setRequestProperty("Content-Type", "application/json");
            con.setRequestProperty("Accept", "application/json");
            con.setRequestProperty("Cookie", sessionId.trim());
            con.setRequestProperty("token", token.trim());
            con.setRequestMethod("PUT");
            OutputStream os = con.getOutputStream();
            os.write(jobject.toString().getBytes("UTF-8"));
            os.flush();
            os.close();
            StringBuilder sb = new StringBuilder();

            int HttpResult =con.getResponseCode();

            responseCode=String.valueOf(HttpResult);

            if(HttpResult ==HttpURLConnection.HTTP_OK){

                BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream(),"utf-8"));

                String line = null;

                while ((line = br.readLine()) != null) {
                    sb.append(line + "\n");
                }

                br.close();
                response=sb.toString();
                con.getRequestMethod();
                Log.v("Post response success", "Post response success" + response);
            }
            else
            {
                BufferedReader br = new BufferedReader(new InputStreamReader(con.getErrorStream(),"utf-8"));

                String line = null;

                while ((line = br.readLine()) != null) {
                    sb.append(line + "\n");
                }

                br.close();
                response=sb.toString();
                con.getRequestMethod();
                Log.v("Post response failure", "Post response failure" + response);
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (ProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }



        return new SignupResponse(responseCode,response);
    }


    public static SignupResponse putWebServiceData(String jobject, String url,String sessionId,String token) {
        URL object= null;
        try {
            object = new URL(url);
            HttpURLConnection con = (HttpURLConnection) object.openConnection();
            con.setDoOutput(true);
            con.setDoInput(true);
            con.setRequestProperty("Content-Type", "application/json");
            con.setRequestProperty("Accept", "application/json");
            con.setRequestProperty("Cookie", sessionId.trim());
            con.setRequestProperty("token", token.trim());
            con.setRequestMethod("PUT");
            OutputStream os = con.getOutputStream();
            os.write(jobject.getBytes("UTF-8"));
            os.flush();
            os.close();
            StringBuilder sb = new StringBuilder();

            int HttpResult =con.getResponseCode();

            responseCode=String.valueOf(HttpResult);

            if(HttpResult ==HttpURLConnection.HTTP_OK){

                BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream(),"utf-8"));

                String line = null;

                while ((line = br.readLine()) != null) {
                    sb.append(line + "\n");
                }

                br.close();
                response=sb.toString();
                con.getRequestMethod();
                Log.v("Post response success", "Post response success" + response);
            }
            else
            {
                BufferedReader br = new BufferedReader(new InputStreamReader(con.getErrorStream(),"utf-8"));

                String line = null;

                while ((line = br.readLine()) != null) {
                    sb.append(line + "\n");
                }

                br.close();
                response=sb.toString();
                con.getRequestMethod();
                Log.v("Post response failure", "Post response failure" + response);
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (ProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }



        return new SignupResponse(responseCode,response);
    }







    public static SignupResponse postImageServiceData(String jobject,String token,String sessionId) {
        Response response = null;
        String resultCode="";
        OkHttpClient  client = new OkHttpClient();
        RequestBody requestBody = new MultipartBuilder()
                .type(MultipartBuilder.FORM)
                .addFormDataPart("imageId", "")
                .addFormDataPart("file", jobject, RequestBody.create(MEDIA_TYPE, new File(jobject)))
                .build();
        Log.v("response requestBody", "response requestBody" + requestBody.toString());
        Request request = new Request.Builder()
                .url("http://192.168.1.105:8080/easyfunding/api/campaign/upload/image/22")
                .post(requestBody)
                .addHeader("token",token)
                .addHeader("Cookie",sessionId)
                .build();
        try {
            response = client.newCall(request).execute();
            System.out.println(response);
            resultCode = String.valueOf(response.code());
            if (!response.isSuccessful()) {

                Log.v("response fail", "response fail" + response.code());
                return new SignupResponse(resultCode,responseCode);

            } else {
                Log.v("response successful", "response successful" + response);
                return new SignupResponse(resultCode,responseCode);

            }
        } catch (IOException e) {
            e.printStackTrace();
        }
          return new SignupResponse(resultCode,responseCode);
      }
}
