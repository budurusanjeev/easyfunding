package com.balarcsoft.easyfunding;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.balarcsoft.easyfunding.adapters.DisasterSingleAdapter;
import com.balarcsoft.easyfunding.models.SingleDisasterModel;
import com.balarcsoft.easyfunding.post.PostDataWebService;
import com.balarcsoft.easyfunding.network.NetworkCheck;
import com.balarcsoft.easyfunding.utils.AppPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by BS-2 on 4/18/2016.
 */
public class SignIn extends BaseActivity {

    private static final String EMAIL_PATTERN = "^[a-zA-Z0-9#_~!$&'()*+,;=:.\"(),:;<>@\\[\\]\\\\]+@[a-zA-Z0-9-]+(\\.[a-zA-Z0-9-]+)*$";
    private Pattern pattern = Pattern.compile(EMAIL_PATTERN);
    private Matcher matcher;
    TextInputLayout password;
    TextInputLayout  email;
    String emailText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup);
        final LinearLayout linearLayout = (LinearLayout)findViewById(R.id.linearLayout);
        TextInputLayout nameInputLayout= (TextInputLayout)findViewById(R.id.input_layout_name);
        TextInputLayout lastNameInputLayout=(TextInputLayout)findViewById(R.id.input_layout_last_name);
         password=(TextInputLayout)findViewById(R.id.input_layout_password);
         email =(TextInputLayout)findViewById(R.id.input_layout_email);
        nameInputLayout.setVisibility(View.GONE);
        lastNameInputLayout.setVisibility(View.GONE);
        Button signinButton = (Button)findViewById(R.id.sign);
        TextView alreadymember = (TextView)findViewById(R.id.alreadyMember);
        TextView forgotPassword = (TextView)findViewById(R.id.forgotPassword);
        signinButton.setText("SignIn");
        alreadymember.setVisibility(View.GONE);
        CheckBox agreeCheckBox=(CheckBox)findViewById(R.id.agreecCheckbox);
        agreeCheckBox.setVisibility(View.GONE);
        forgotPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Dialog dialog = new Dialog(SignIn.this);
                dialog.setContentView(R.layout.forgotpassword);
                // set the custom dialog components - text, image and button
                TextView text = (TextView) dialog.findViewById(R.id.signin);
                final TextInputLayout  email =(TextInputLayout)dialog.findViewById(R.id.input_layout_email);
                dialog.show();
                 text.setOnClickListener(new View.OnClickListener() {
                   @Override
                   public void onClick(View v) {
                       dialog.dismiss();
                   }
               });

                Button dialogButton = (Button) dialog.findViewById(R.id.sendmail);
                // if button is clicked, close the custom dialog
                dialogButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(!validateEmail(email.getEditText().getText().toString()))
                        {
                            email.setErrorEnabled(true);
                            email.setError("Not a valid email address!");
                        }
                        else {
                            email.setError(null);
                            email.setErrorEnabled(false);
                            emailText=email.getEditText().getText().toString();

                            /*ArrayList arrayList = new ArrayList();
                            arrayList.add(email.getEditText().getText().toString());
                            arrayList.add(Constants.FORGOT_PASSWORD);
*/
                            forgotPasswordRequest();

                          /*  new ForgotAsyncTask()
                            {
                                @Override
                                protected void onPostExecute(SignupResponse signupResponse) {
                                    super.onPostExecute(signupResponse);
                                if(signupResponse.getResponse().equals("200"))
                                {
                                    dialog.dismiss();
                                    Toast.makeText(getApplicationContext(),"Success",Toast.LENGTH_LONG).show();
                                }else
                                {
                                    Toast.makeText(getApplicationContext(),"Failure",Toast.LENGTH_LONG).show();
                                }
                                }
                            }.execute(arrayList);*/
                        }
                    }
                });

            }
        });

        signinButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String   connection = NetworkCheck.getConnectivityStatusString(getApplicationContext());

               // JSONObject jsonObject = null;
                if (!connection.equals("No Internet Connection")) {


                    if (!validateEmail(email.getEditText().getText().toString())||
                            password.getEditText().getText().length()<6)
                    {
                        if(password.getEditText().getText().length()<6) {
                            password.setErrorEnabled(true);
                            password.setError("Maximum length of password is 6");
                        }else
                        {
                            password.setError(null);
                            password.setErrorEnabled(false);
                        }
                        if(!validateEmail(email.getEditText().getText().toString()))
                        {
                            email.setErrorEnabled(true);
                            email.setError("Not a valid email address!");
                        }
                        else {
                            email.setError(null);
                            email.setErrorEnabled(false);
                        }

                    }else
                    {
                        email.setError(null);
                        email.setErrorEnabled(false);
                        password.setError(null);
                        password.setErrorEnabled(false);

                        sendRequest();

                    }
                }
                else
                {
                    Snackbar snackbar = Snackbar.make(linearLayout, "No Internet Connection ", Snackbar.LENGTH_INDEFINITE);
                    snackbar.getView().setBackgroundColor(Color.WHITE);
                    View snackbarView = snackbar.getView();
                    TextView textView = (TextView) snackbarView.findViewById(android.support.design.R.id.snackbar_text);
                    textView.setTextColor(Color.parseColor("#0a6b58"));
                    snackbar.show();
                }

            }
        });
    }

    private void forgotPasswordRequest()
    {
        //final String loginCredentials    = "Password=" + password.getEditText().getText().toString() + "&Username=" + email.getEditText().getText().toString();
        String url = Constants.FORGOT_PASSWORD;

        StringRequest stringRequest = new StringRequest(2,url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        Toast.makeText(SignIn.this, "Success", Toast.LENGTH_LONG).show();
                    }
                },

                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(SignIn.this, String.valueOf(error.networkResponse.statusCode), Toast.LENGTH_LONG).show();
                    }
                })
        {
           /* @Override
            protected Map<String, String> getParams()
            {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("content-Type", "text/plain");
                // volley will escape this for you
               // params.put("Accept", "application/json");
                return params;
            }*/

           /* @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("content-Type", "text/plain");
                return params;
            }*/

            @Override
            public byte[] getBody() throws AuthFailureError {
                //  String httpPostBody="grant_type=password&username=Alice&password=password123";
                // usually you'd have a field with some values you'd want to escape, you need to do it yourself if overriding getBody. here's how you do it
              /*  try {
                    emailText=emailText+"&randomFieldFilledWithAwkwardCharacters="+ URLEncoder.encode("{{%stuffToBe Escaped/", "UTF-8");
                } catch (UnsupportedEncodingException exception) {
                    Log.e("ERROR", "exception", exception);
                    // return null and don't pass any POST string if you encounter encoding error
                    return null;
                }*/
                return emailText.getBytes();
            }

        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    public boolean validateEmail(String email) {
        matcher = pattern.matcher(email);
        return matcher.matches();
    }

    private void sendRequest()  {
     final String loginCredentials    = "Password=" + password.getEditText().getText().toString() + "&Username=" + email.getEditText().getText().toString();
        String url = Constants.SIGN_IN;

        StringRequest stringRequest = new StringRequest(1,url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try
                        {
                            JSONObject loginSuccess = new JSONObject(response);
                            AppPreferences appPreferences = new AppPreferences(getApplicationContext());
                            appPreferences.setEmailId(loginSuccess.getString("userName"));
                            appPreferences.setProfileId(loginSuccess.getString("profileId"));
                            appPreferences.setPassword(password.getEditText().getText().toString());
                            Toast.makeText(getApplicationContext(),"Login Success ",Toast.LENGTH_LONG).show();
                            startActivity(new Intent(getApplicationContext(), MyCampaign.class));
                            finish();
                        }
                        catch (Exception e)
                        {
                            e.printStackTrace();
                        }

                    }
                },

                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        if (error instanceof TimeoutError || error instanceof NoConnectionError)
                        {
                            Toast.makeText(getApplicationContext(), "ConnectionError",
                                    Toast.LENGTH_LONG).show();
                        } else if (error instanceof ServerError)
                        {

                            Toast.makeText(getApplicationContext(), "ServerError",
                                    Toast.LENGTH_LONG).show();
                        } else if (error instanceof NetworkError)
                        {
                            Toast.makeText(getApplicationContext(), "NetworkError",
                                    Toast.LENGTH_LONG).show();

                        }
                        else if(error.networkResponse.data!=null) {
                    String body= null;
                    //get status code here
                    //   String statusCode = String.valueOf(error.networkResponse.statusCode);
                    //get response body and parse with appropriate encoding
                    try {
                        body = new String(error.networkResponse.data,"UTF-8");
                        JSONObject failJsonObject = new JSONObject(body);
                        new android.app.AlertDialog.Builder(SignIn.this)
                                .setMessage(failJsonObject.getString("message"))
                                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.cancel();
                                    }
                                })
                                .show();
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

                    }
                })
        {
            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("content-Type", "application/x-www-form-urlencoded");
                // volley will escape this for you
                params.put("Accept", "application/json");
                return params;
            }
            @Override
            public byte[] getBody() throws AuthFailureError {
              //  String httpPostBody="grant_type=password&username=Alice&password=password123";
                // usually you'd have a field with some values you'd want to escape, you need to do it yourself if overriding getBody. here's how you do it
               /* try {
                   // loginCredentials=loginCredentials+"&randomFieldFilledWithAwkwardCharacters="+ URLEncoder.encode("{{%stuffToBe Escaped/", "UTF-8");
                } catch (UnsupportedEncodingException exception) {
                    Log.e("ERROR", "exception", exception);
                    // return null and don't pass any POST string if you encounter encoding error
                    return null;
                }*/
                return loginCredentials.getBytes();
            }
            @Override
            protected Response<String> parseNetworkResponse(NetworkResponse response) {

                try {
                    if(response!=null) {
                        String json = new String(
                                response.data, HttpHeaderParser.parseCharset(response.headers));
                        AppPreferences appPreferences ;
                        //appPreferences.setTokenId(response.headers.get("token"));
                        //String cookie = response.headers.get("Set-Cookie");
                        String cookie = response.headers.get("Set-Cookie");
                        if(response.headers.get("token")!=null)
                        {
                            appPreferences= new AppPreferences(getApplicationContext());
                            appPreferences.setTokenId(response.headers.get("token"));
                        }
                        if(cookie!=null) {
                            String[] abc = cookie.split(";");
                            Log.v("cookie", "cookie" + abc[0]);
                            Log.v("cookie", "cookie" + abc[1]);
                            Log.v("cookie", "cookie" + cookie);
                            appPreferences= new AppPreferences(getApplicationContext());
                            appPreferences.setSessionId(abc[0]);
                        }
                        return Response.success(
                                json, HttpHeaderParser.parseCacheHeaders(response));
                    }
                } catch (UnsupportedEncodingException e) {
                    return Response.error(new ParseError(e));
                }
                return null;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }


    public class ForgotAsyncTask extends AsyncTask<ArrayList, SignupResponse, SignupResponse> {
        SignupResponse signupResponse;

        @Override
        protected SignupResponse doInBackground(ArrayList... params) {

            String jobject= (String) params[0].get(0);
            String url= (String) params[0].get(1);

            try
            {
                signupResponse = PostDataWebService.postWebServiceData(jobject, url);
            }
            catch (final Exception e)
            {
                e.printStackTrace();

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getApplicationContext(),""+e.getMessage(),Toast.LENGTH_LONG).show();
                    }
                });
                Log.v("server Exception", "Exception : "
                        + e.getMessage(), e);
            }

            return signupResponse;
        }

    }

}
