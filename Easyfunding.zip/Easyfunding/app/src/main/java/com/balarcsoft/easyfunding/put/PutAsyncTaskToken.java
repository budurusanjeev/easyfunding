package com.balarcsoft.easyfunding.put;

import android.os.AsyncTask;
import android.util.Log;

import com.balarcsoft.easyfunding.SignupResponse;

import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by BS2 on 01-07-2015.
 */
public class PutAsyncTaskToken extends AsyncTask<ArrayList, SignupResponse, SignupResponse> {
    SignupResponse signupResponse;
    @Override
    protected SignupResponse doInBackground(ArrayList... params) {
        String response = "";
        JSONObject jobject= (JSONObject) params[0].get(0);
        String url= (String) params[0].get(1);
        String sessionId= (String)params[0].get(2);
        String token =(String)params[0].get(3);
        Log.v("token", "token sess: " + sessionId);
        Log.v("token", "token sess : " + token);
        try {

            signupResponse = PutDataWebService.putWebServiceData(jobject, url, sessionId, token);
            Log.e("server response", "response: "
                    + response);
        }
        catch (Exception e)
        {
            e.printStackTrace();


            Log.v("server Exception", "Exception : "
                    + e.getMessage(), e);
        }

        return signupResponse;
    }



}
