package com.balarcsoft.easyfunding;

import android.os.AsyncTask;
import android.util.Log;

import com.balarcsoft.easyfunding.post.PostDataWebService;
import com.balarcsoft.easyfunding.put.PutDataWebService;

import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by BS-2 on 5/26/2016.
 */
public class PutAsyncTaskVisibleCampaign extends AsyncTask<ArrayList, SignupResponse, SignupResponse> {
    SignupResponse signupResponse;


    @Override
    protected SignupResponse doInBackground(ArrayList... params) {
        String jobject= (String) params[0].get(0);
        String url= (String) params[0].get(1);
        String sessionId = (String) params[0].get(2);
        String token = (String)params[0].get(3);
        try {
            signupResponse = PutDataWebService.putWebServiceData(jobject, url, sessionId, token);
            Log.e("server response", "response: " + signupResponse.getResult() + "\t" + signupResponse.getResponse());
        }
        catch (Exception e)
        {
            e.printStackTrace();


            Log.v("server Exception", "Exception : "
                    + e.getMessage(), e);
        }

        return signupResponse;
    }



}
