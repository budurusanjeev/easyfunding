package com.balarcsoft.easyfunding;

import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.balarcsoft.easyfunding.adapters.DisasterSingleAdapter;
import com.balarcsoft.easyfunding.get.GetAsyncTask;
import com.balarcsoft.easyfunding.models.SingleDisasterModel;
import com.balarcsoft.easyfunding.network.NetworkCheck;
import com.balarcsoft.easyfunding.post.PostAsyncTaskToken;
import com.balarcsoft.easyfunding.utils.AppPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by BS-2 on 4/19/2016.
 */
public class AccountSettings extends BaseActivity {
    EditText editTextFirstName , editTextLastName, editTextEmail , editTextPhone;
    TextInputLayout textInputOldPassword,textInputNewPassword,input_layout_conformpassword;
    String requestBody;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.accountsettings);
        final LinearLayout linearLayout = (LinearLayout)findViewById(R.id.linearLayout);
        final TextInputLayout textInputFirstName = (TextInputLayout) findViewById(R.id.input_layout_firstName);
        final TextInputLayout textInputLastName = (TextInputLayout) findViewById(R.id.input_layout_lastName);
        final TextInputLayout textInputEmail = (TextInputLayout) findViewById(R.id.input_layout_email);
        final TextInputLayout textInputPhone = (TextInputLayout) findViewById(R.id.input_layout_phone);
         textInputOldPassword = (TextInputLayout) findViewById(R.id.input_layout_oldpassword);
         textInputNewPassword = (TextInputLayout) findViewById(R.id.input_layout_newpassword);
         input_layout_conformpassword = (TextInputLayout) findViewById(R.id.input_layout_conformpassword);
       // input_layout_oldpassword  input_layout_newpassword
        editTextFirstName = (EditText)findViewById(R.id.input_firstName);
         editTextLastName = (EditText)findViewById(R.id.input_lastName);
        editTextEmail = (EditText)findViewById(R.id.input_email);
         editTextPhone = (EditText)findViewById(R.id.input_firstName);
        Button updateDetails = (Button) findViewById(R.id.update);
        Button changePassword = (Button) findViewById(R.id.changePassword);

        changePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                String   connection = NetworkCheck.getConnectivityStatusString(getApplicationContext());

                if (!connection.equals("No Internet Connection")) {
                if(TextUtils.isEmpty(textInputOldPassword.getEditText().getText())
                        ||TextUtils.isEmpty(textInputNewPassword.getEditText().getText())
                        ||TextUtils.isEmpty(input_layout_conformpassword.getEditText().getText()))
                {
                    if(TextUtils.isEmpty(textInputOldPassword.getEditText().getText()))
                    {
                        textInputOldPassword.setErrorEnabled(true);
                        textInputOldPassword.setError("Old password is empty");
                    }else
                    {
                        textInputOldPassword.setError(null);
                        textInputOldPassword.setErrorEnabled(false);
                    }

                    if(TextUtils.isEmpty(textInputNewPassword.getEditText().getText()))
                    {
                        textInputNewPassword.setErrorEnabled(true);
                        textInputNewPassword.setError("New password is empty");
                    }else
                    {
                        textInputNewPassword.setError(null);
                        textInputNewPassword.setErrorEnabled(false);
                    }

                    if(TextUtils.isEmpty(input_layout_conformpassword.getEditText().getText()))
                    {
                        input_layout_conformpassword.setErrorEnabled(true);
                        input_layout_conformpassword.setError("Conform password is empty");
                    }else
                    {
                        input_layout_conformpassword.setError(null);
                        input_layout_conformpassword.setErrorEnabled(false);
                    }

                }
                else
                {

                    if(input_layout_conformpassword.getEditText().getText().toString().equals(textInputNewPassword.getEditText().getText().toString()))
                    {
                        textInputOldPassword.setError(null);
                        textInputOldPassword.setErrorEnabled(false);
                        textInputNewPassword.setError(null);
                        textInputNewPassword.setErrorEnabled(false);
                        input_layout_conformpassword.setError(null);
                        input_layout_conformpassword.setErrorEnabled(false);
                        //sendEditRequest();

                        try {
                            JSONObject jsonObject = new JSONObject();
                            jsonObject.put("oldPwd", textInputOldPassword.getEditText().getText().toString());
                            jsonObject.put("newPwd", textInputNewPassword.getEditText().getText().toString());
                            final AppPreferences appPreferences = new AppPreferences(getApplicationContext());
                            ArrayList changepassword = new ArrayList();
                            changepassword.add(jsonObject);
                            changepassword.add(Constants.CHANGE_PASSWORD);
                            changepassword.add(appPreferences.getSessionId());
                            changepassword.add(appPreferences.getTokenId());

                            new PostAsyncTaskToken() {
                                @Override
                                protected void onPostExecute(SignupResponse signupResponse) {
                                    super.onPostExecute(signupResponse);
                                    if (signupResponse.getResponse().equals("200"))
                                    {
                                        appPreferences.setPassword(textInputNewPassword.getEditText().getText().toString());
                                        Toast.makeText(getApplicationContext(), "Password Updated", Toast.LENGTH_LONG).show();
                                    }else
                                    {
                                        Toast.makeText(getApplicationContext(), "Password not Updated", Toast.LENGTH_LONG).show();
                                    }
                                }
                            }.execute(changepassword);
                        }catch (Exception e)
                        {
                            e.printStackTrace();
                        }
                    }else
                    {
                        input_layout_conformpassword.setErrorEnabled(true);
                        input_layout_conformpassword.setError("Password doesn't match");
                    }
                }
            }else
                {
                    Snackbar snackbar = Snackbar.make(linearLayout, "No Internet Connection ", Snackbar.LENGTH_INDEFINITE);
                    snackbar.getView().setBackgroundColor(Color.WHITE);
                    View snackbarView = snackbar.getView();
                    TextView textView = (TextView) snackbarView.findViewById(android.support.design.R.id.snackbar_text);
                    textView.setTextColor(Color.parseColor("#0a6b58"));
                    snackbar.show();
                }
            }
        });


        String   connection = NetworkCheck.getConnectivityStatusString(getApplicationContext());

        if (!connection.equals("No Internet Connection")) {

            sendRequest();

        }else
        {
            Snackbar snackbar = Snackbar.make(linearLayout, "No Internet Connection ", Snackbar.LENGTH_INDEFINITE);
            snackbar.getView().setBackgroundColor(Color.WHITE);
            View snackbarView = snackbar.getView();
            TextView textView = (TextView) snackbarView.findViewById(android.support.design.R.id.snackbar_text);
            textView.setTextColor(Color.parseColor("#0a6b58"));
            snackbar.show();
        }

        updateDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }

    private void sendRequest() {
        AppPreferences appPreferences = new AppPreferences(getApplicationContext());
        String url = Constants.GET_CAMPAIGNER_DETAILS + appPreferences.getProfileId();
        final JsonObjectRequest jsonArrayRequest = new JsonObjectRequest(url, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    editTextFirstName.setText(response.getString("firstName"));
                    editTextLastName.setText(response.getString("lastName"));
                    editTextEmail.setText(response.getString("userName"));
                    if (!response.getString("phone").equals("null")) {
                        editTextPhone.setText(response.getString("phone"));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                if (error instanceof TimeoutError || error instanceof NoConnectionError) {
                    Toast.makeText(getApplicationContext(), "ConnectionError",
                            Toast.LENGTH_LONG).show();
                } else if (error instanceof ServerError) {

                    Toast.makeText(getApplicationContext(), "ServerError",
                            Toast.LENGTH_LONG).show();
                } else if (error instanceof NetworkError) {
                    Toast.makeText(getApplicationContext(), "NetworkError",
                            Toast.LENGTH_LONG).show();
                } else if(error.networkResponse.data!=null) {
                    String body= null;
                    //get status code here
                    //   String statusCode = String.valueOf(error.networkResponse.statusCode);
                    //get response body and parse with appropriate encoding
                    try {
                        body = new String(error.networkResponse.data,"UTF-8");
                        JSONObject failJsonObject = new JSONObject(body);
                        new android.app.AlertDialog.Builder(AccountSettings.this)
                                .setMessage(failJsonObject.getString("message"))
                                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.cancel();
                                    }
                                })
                                .show();
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }


            }
        }){ @Override
        public Map<String, String> getHeaders ()throws AuthFailureError {
               AppPreferences  appPreferences = new AppPreferences(getApplicationContext());
            Map<String, String> params = new HashMap<String, String>();
            params.put("token", appPreferences.getTokenId());
            params.put("Cookie",appPreferences.getSessionId());
            return params;
        }


            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("Content-Type", "application/json");
                params.put("Accept", "application/json");
                return params;
            }
    };
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(jsonArrayRequest);

    }


}
