package com.balarcsoft.easyfunding.adapters;

import android.app.Activity;
import android.graphics.Bitmap;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SwitchCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.balarcsoft.easyfunding.Constants;
import com.balarcsoft.easyfunding.PutAsyncTaskVisibleCampaign;
import com.balarcsoft.easyfunding.R;
import com.balarcsoft.easyfunding.SignupResponse;
import com.balarcsoft.easyfunding.models.DonationModel;
import com.balarcsoft.easyfunding.utils.AppPreferences;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;
import com.nostra13.universalimageloader.core.display.FadeInBitmapDisplayer;

import java.util.ArrayList;

/**
 * Created by BS-2 on 6/9/2016.
 */
public class DonationListAdapter extends RecyclerView.Adapter<DonationListAdapter.DataObjectHolder> {
    public Activity context;
    AppPreferences appPreferences;
    DisplayImageOptions options;
    private ArrayList<DonationModel> mDataset;

    public DonationListAdapter(ArrayList<DonationModel> myDataset, Activity applicationContext) {
        this.mDataset = myDataset;
        this.context = applicationContext;
        appPreferences = new AppPreferences(context);

        options = new DisplayImageOptions.Builder()
                .imageScaleType(ImageScaleType.IN_SAMPLE_INT)
                .considerExifParams(true)
                .bitmapConfig(Bitmap.Config.RGB_565)
                .displayer(new FadeInBitmapDisplayer(2000))
                .build();
    }

    @Override
    public DonationListAdapter.DataObjectHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.donationlistrow, parent, false);

        DataObjectHolder dataObjectHolder = new DataObjectHolder(view);
        return dataObjectHolder;
    }

    @Override
    public void onBindViewHolder(final DonationListAdapter.DataObjectHolder holder, int position) {
       // final int pos = position;
        holder.campaignName.setText(mDataset.get(position).getName());
        holder.campaignPostedDate.setText( mDataset.get(position).getDonatedDate());
        holder.campaignGoalAmount.setText(String.valueOf(mDataset.get(position).getAmount()));
        holder.campaigntype.setText(mDataset.get(position).getPaymentType());
    }

    @Override
    public int getItemCount() {
        return mDataset.size();
    }

    public class DataObjectHolder extends RecyclerView.ViewHolder
            implements View
            .OnClickListener {
        public TextView campaignName, campaignPostedDate, campaigntype, campaignGoalAmount;


        public DataObjectHolder(View itemView) {
            super(itemView);

            campaignName = (TextView) itemView.findViewById(R.id.name);
            campaignPostedDate = (TextView) itemView.findViewById(R.id.amount);
            campaignGoalAmount = (TextView) itemView.findViewById(R.id.donatedDate);
            campaigntype = (TextView) itemView.findViewById(R.id.type);

            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {

        }
    }

}
