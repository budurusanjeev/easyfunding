package com.balarcsoft.easyfunding;

import android.os.AsyncTask;
import android.util.Log;

import com.balarcsoft.easyfunding.post.PostDataWebService;

import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by BS2 on 01-07-2015.
 */
public class Postasynctask extends AsyncTask<ArrayList, SignupResponse, SignupResponse> {
    SignupResponse signupResponse;


    @Override
    protected SignupResponse doInBackground(ArrayList... params) {
        JSONObject jobject= (JSONObject) params[0].get(0);
        String url= (String) params[0].get(1);
        try {
            signupResponse = PostDataWebService.postWebServiceData(jobject, url);
            Log.e("server response", "response: " + signupResponse.getResult() +"\t"+ signupResponse.getResponse());
        }
        catch (Exception e)
        {
            e.printStackTrace();


            Log.v("server Exception", "Exception : "
                    + e.getMessage(), e);
        }

        return signupResponse;
    }



}
