package com.balarcsoft.easyfunding;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.balarcsoft.easyfunding.adapters.ImagePagerAdapter;
import com.balarcsoft.easyfunding.adapters.MyCampaignAdapter;
import com.balarcsoft.easyfunding.get.GetAsyncTask;
import com.balarcsoft.easyfunding.models.MyCampaignModel;
import com.balarcsoft.easyfunding.network.NetworkCheck;
import com.balarcsoft.easyfunding.utils.AppPreferences;
import com.google.android.gms.analytics.HitBuilders;
import com.google.android.gms.analytics.Tracker;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by BS-2 on 4/19/2016.
 */
public class MyCampaign extends BaseActivity {
    ArrayList<MyCampaignModel> myCampaignModels;
    String connection;
    FrameLayout frameLayout;
    Tracker mTracker;
    RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mycampaign);
        EasyFundingApplication application = (EasyFundingApplication) getApplication();
        mTracker = application.getDefaultTracker();
        recyclerView = (RecyclerView) findViewById(R.id.recycler_view);
        frameLayout = (FrameLayout)findViewById(R.id.postFrame);
        FloatingActionButton postCampaign = (FloatingActionButton) findViewById(R.id.postCampaign);
        connection= NetworkCheck.getConnectivityStatusString(MyCampaign.this);
        myCampaignModels = new ArrayList<MyCampaignModel>();
        postCampaign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AppPreferences appPreferences = new AppPreferences(getApplicationContext());
                appPreferences.setMode("new");
                startActivity(new Intent(MyCampaign.this, PostCampaign.class));
            }
        });
        // use this setting to improve performance if you know that changes
        // in content do not change the layout size of the RecyclerView
        recyclerView.setHasFixedSize(true);

        LinearLayoutManager mLayoutManager = new LinearLayoutManager(this);

        // use a linear layout manager
        recyclerView.setLayoutManager(mLayoutManager);

        if (!connection.equals("No Internet Connection"))
        {
            sendRequest();
        }
        else
        {
            Snackbar snackbar=Snackbar.make(frameLayout, "No Internet Connection", Snackbar.LENGTH_INDEFINITE);
            snackbar.getView().setBackgroundColor(Color.WHITE);
            View snackbarView = snackbar.getView();
            TextView textView = (TextView) snackbarView.findViewById(android.support.design.R.id.snackbar_text);
            textView.setTextColor(Color.parseColor("#0a6b58"));
            snackbar.show();
        }
    }

    private void sendRequest() {

        AppPreferences appPreferences = new AppPreferences(getApplicationContext());
        String url = Constants.GET_ALL_CAMPAIGNS+appPreferences.getProfileId();

        JsonArrayRequest stringRequest = new JsonArrayRequest(Request.Method.GET,url,new Response.Listener<JSONArray>()
        {
            @Override
            public void onResponse(JSONArray response) {
                try {

                    int size = response.length();
                    for (int s = 0; s < size; s++) {
                        JSONObject jsonObject = response.getJSONObject(s);
                        MyCampaignModel myCampaignModel = new MyCampaignModel();
                        myCampaignModel.setId(jsonObject.getString("id"));
                        myCampaignModel.setCampaignName(jsonObject.getString("title"));
                        myCampaignModel.setSelected(jsonObject.getBoolean("active"));
                        BigDecimal amount = new BigDecimal(0);
                        String a = jsonObject.getString("amount");

                        if (a != null && a.trim().length() > 0) {
                            amount = new BigDecimal(a.trim());
                        }

                        myCampaignModel.setCampaignGoalAmount(jsonObject.getInt("amount"));
                        myCampaignModel.setCampaignPostedDate(jsonObject.getString("postedDate"));
                        myCampaignModel.setLiked("0");
                        String dons = jsonObject.getString("totalDonations");
                        BigDecimal donations = new BigDecimal(0);
                        int percentage = 0;
                        if (dons != null && !dons.equals("null") && dons.trim().length() > 0) {
                            donations = new BigDecimal(dons.trim());
                        }
                        if (donations.compareTo(new BigDecimal(0)) == 1) {
                            //a.divide(b, 2, RoundingMode.HALF_UP
                            percentage = (donations.divide(amount, 2, RoundingMode.HALF_UP).multiply(new BigDecimal(100))).intValue();
                            Log.v("percentage", "percentage" + String.valueOf(percentage));
                        }
                        myCampaignModel.setCampaignRaisedAmount(donations);

                        myCampaignModel.setCampaignPercentage(percentage);
                        JSONArray jsonArray1 = jsonObject.getJSONArray("images");
                        if (jsonArray1.length() > 0) {
                            JSONObject jsonObjectImage = jsonArray1.getJSONObject(0);
                            myCampaignModel.setCampaignImageUrl(jsonObjectImage.getString("imageUrl"));
                        } else {
                            myCampaignModel.setCampaignImageUrl("https://s3-us-west-2.amazonaws.com/easyfunding/test_campaign/12.png");
                        }
                        myCampaignModels.add(myCampaignModel);
                        Log.v("cam name", "cam name" + myCampaignModels.get(s).getCampaignName());
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                MyCampaignAdapter mAdapter = new MyCampaignAdapter(myCampaignModels, MyCampaign.this);

                // set the adapter object to the Recyclerview
                recyclerView.setAdapter(mAdapter);

            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                String body= null;
                //get status code here
                //   String statusCode = String.valueOf(error.networkResponse.statusCode);
                //get response body and parse with appropriate encoding
                if (error instanceof TimeoutError || error instanceof NoConnectionError)
                {
                    Toast.makeText(getApplicationContext(), "ConnectionError",
                            Toast.LENGTH_LONG).show();
                } else if (error instanceof ServerError)
                {

                    Toast.makeText(getApplicationContext(), "ServerError",
                            Toast.LENGTH_LONG).show();
                } else if (error instanceof NetworkError)
                {
                    Toast.makeText(getApplicationContext(), "NetworkError",
                            Toast.LENGTH_LONG).show();

                }else
                if(error.networkResponse.data!=null) {
                    try {
                        body = new String(error.networkResponse.data,"UTF-8");
                        Log.v("error","error  "+body);
                        Log.v("error","error  "+body);
                        JSONObject failJsonObject = new JSONObject(body);
                        new android.app.AlertDialog.Builder(MyCampaign.this)
                                .setMessage(failJsonObject.getString("message"))
                                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.cancel();
                                    }
                                })
                                .show();
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

            }
        })
        {

            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("content-Type", "application/json");
                params.put("Accept", "application/json");
                return params;
            }

            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                final AppPreferences  appPreferences = new AppPreferences(getApplicationContext());
                Map<String, String>  params = new HashMap<String, String>();
                params.put("Cookie", appPreferences.getSessionId().trim());
                params.put("token", appPreferences.getTokenId().trim());
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }

    @Override
    protected void onResume() {
        super.onResume();

        mTracker.setScreenName("Mycampign");
        mTracker.send(new HitBuilders.ScreenViewBuilder().build());
    }
}
