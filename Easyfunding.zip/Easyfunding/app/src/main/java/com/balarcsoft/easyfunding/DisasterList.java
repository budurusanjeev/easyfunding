package com.balarcsoft.easyfunding;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.BottomSheetBehavior;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.balarcsoft.easyfunding.adapters.DisastersAdapter;
import com.balarcsoft.easyfunding.models.DisasterModel;
import com.balarcsoft.easyfunding.network.NetworkCheck;

import java.util.ArrayList;

/**
 * Created by BS-2 on 4/18/2016.
 */
public class DisasterList extends BaseActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.disasterlist);
        CardView latestCardView = (CardView)findViewById(R.id.cardViewLatest);
        CardView cardViewMostpopular = (CardView)findViewById(R.id.cardViewMostpopular);
        CardView cardViewLesstime = (CardView)findViewById(R.id.cardViewLesstime);
        CardView cardViewalmostComplete = (CardView)findViewById(R.id.cardViewalmostComplete);
        FloatingActionButton moreCategories = (FloatingActionButton) findViewById(R.id.moreCategories);

        latestCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
startActivity(new Intent(DisasterList.this,CommonCampaignsList.class).putExtra("category","latest"));
            }
        });

         cardViewalmostComplete.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 startActivity(new Intent(DisasterList.this,CommonCampaignsList.class).putExtra("category","almost"));
             }
         });
        cardViewLesstime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(DisasterList.this,CommonCampaignsList.class).putExtra("category","lesstime"));
            }
        });
     cardViewMostpopular.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        startActivity(new Intent(DisasterList.this,CommonCampaignsList.class).putExtra("category","mostpopular"));
    }
    });

        moreCategories.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        new CustomBottomSheetDialogFragment().show(getSupportFragmentManager(), "Dialog");
       }
      });


    }

}
