package com.balarcsoft.easyfunding;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.balarcsoft.easyfunding.adapters.DisasterSingleAdapter;
import com.balarcsoft.easyfunding.models.SingleDisasterModel;
import com.balarcsoft.easyfunding.network.NetworkCheck;
import com.google.android.gms.analytics.HitBuilders;
import com.google.android.gms.analytics.Tracker;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by BS-2 on 4/18/2016.
 */
public class Latest extends Fragment {
    ArrayList<SingleDisasterModel> disasterList;
    TextView textView;
    RecyclerView recyclerView;
    ProgressBar progessBar;
    Tracker mTracker;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View viewGroup = inflater.inflate(R.layout.disasterlist, container, false);
        recyclerView =(RecyclerView)viewGroup.findViewById(R.id.recycler_view);
        textView = (TextView)viewGroup.findViewById(R.id.check);
        progessBar =(ProgressBar)viewGroup.findViewById(R.id.progressBar);
        disasterList = new ArrayList<SingleDisasterModel>();
        // use this setting to improve performance if you know that changes
        // in content do not change the layout size of the RecyclerView
        EasyFundingApplication application = (EasyFundingApplication) getActivity().getApplication();
        mTracker = application.getDefaultTracker();
        String   connection = NetworkCheck.getConnectivityStatusString(getActivity());

        if (!connection.equals("No Internet Connection")) {
            try {

                sendRequest();

            } catch (Exception e) {
              //  Toast.makeText(getActivity(), "Due to network issue unable to connect to server", Toast.LENGTH_LONG).show();
                e.printStackTrace();
            }
        }else
        {
            progessBar.setVisibility(View.GONE);
            recyclerView.setVisibility(View.GONE);
            textView.setVisibility(View.VISIBLE);
            textView.setText("No Internet Connection");
        }
        return viewGroup;
    }


    private void sendRequest()  {
        JSONObject latestJson = new JSONObject();
        try {
            latestJson.put("latestFilter", "true");
            latestJson.put("nearFilter", "false");
            latestJson.put("lessTimeFilter", "false");
            latestJson.put("popularFilter", "false");
        } catch (JSONException e) {
            e.printStackTrace();
        }

        final JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Constants.SEARCH_CAMPAIGNER, latestJson ,new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response)
            {
                textView.setVisibility(View.GONE);
                recyclerView.setVisibility(View.VISIBLE);
                progessBar.setVisibility(View.GONE);
                try{
                    int len = response.length();
                        for (int s = 0; s < len; s++)
                        {
                            JSONObject jsonObject = response.getJSONObject(s);
                            if(jsonObject.getString("active").equals("true"))
                            {
                                SingleDisasterModel disasterModel = new SingleDisasterModel();
                                disasterModel.setId(jsonObject.getString("id"));
                                Log.v("id","id"+jsonObject.getString("id"));
                                disasterModel.setDisasterName(jsonObject.getString("title"));
                                disasterModel.setGoalAmount(jsonObject.getString("amount"));
                                disasterModel.setDonatedAmount(jsonObject.getString("totalDonations"));
                                disasterModel.setLocation(jsonObject.getString("location"));
                                disasterModel.setDateCity(jsonObject.getString("postedDate"));
                                JSONArray jsonArray1 = jsonObject.getJSONArray("images");
                                if (jsonArray1.length() > 0) {
                                    JSONObject jsonObjectImage = jsonArray1.getJSONObject(0);
                                    disasterModel.setImageUrl(jsonObjectImage.getString("imageUrl"));
                                } else {
                                    disasterModel.setImageUrl("https://s3-us-west-2.amazonaws.com/easyfunding/test_campaign/12.png");
                                }
                                disasterList.add(disasterModel);
                        }

                    }
                    recyclerView.setAdapter( new DisasterSingleAdapter(disasterList, getActivity()) );
                    LinearLayoutManager llm = new LinearLayoutManager(getActivity());
                    llm.setOrientation(LinearLayoutManager.VERTICAL);
                    recyclerView.setLayoutManager(llm);
                }catch (JSONException e){
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progessBar.setVisibility(View.GONE);
                recyclerView.setVisibility(View.GONE);
                textView.setVisibility(View.VISIBLE);

                if (error instanceof TimeoutError || error instanceof NoConnectionError)
                {
                    Toast.makeText(getContext(), "ConnectionError",
                            Toast.LENGTH_LONG).show();
                } else if (error instanceof ServerError)
                {

                    Toast.makeText(getContext(), "ServerError",
                            Toast.LENGTH_LONG).show();
                } else if (error instanceof NetworkError)
                {
                    Toast.makeText(getContext(), "NetworkError",
                            Toast.LENGTH_LONG).show();

                }
            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        requestQueue.add(jsonArrayRequest);
    }

    @Override
    public void onResume() {
        super.onResume();
        mTracker.setScreenName("Latest");
        mTracker.send(new HitBuilders.ScreenViewBuilder().build());
    }


}
