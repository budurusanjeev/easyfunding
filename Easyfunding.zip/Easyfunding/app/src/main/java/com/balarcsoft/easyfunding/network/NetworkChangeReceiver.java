package com.balarcsoft.easyfunding.network;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Created by BS2 on 14-07-2015.
 */
public abstract class NetworkChangeReceiver extends BroadcastReceiver {

    public String status;
    @Override
    public void onReceive(final Context context, final Intent intent) {

        status= NetworkCheck.getConnectivityStatusString(context);
        onNetworkChange(status);
    }

   public  abstract void onNetworkChange(String connection);

}
