package com.balarcsoft.easyfunding.models;

/**
 * Created by BS-2 on 5/7/2016.
 */
public class ImageModel {
    String campaignId;

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getCampaignId() {
        return campaignId;
    }

    public void setCampaignId(String campaignId) {
        this.campaignId = campaignId;
    }

    String imageUrl;
}
