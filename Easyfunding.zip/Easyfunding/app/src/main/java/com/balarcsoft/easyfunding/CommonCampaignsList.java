package com.balarcsoft.easyfunding;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Toast;

import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.balarcsoft.easyfunding.adapters.DisasterSingleAdapter;
import com.balarcsoft.easyfunding.models.SingleDisasterModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

/**
 * Created by BS-2 on 6/4/2016.
 */
public class CommonCampaignsList extends BaseActivity {

    RecyclerView recyclerView;
    ArrayList<SingleDisasterModel> disasterList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mycampaign);
        String category = getIntent().getExtras().getString("category");
        FloatingActionButton floatingActionButton = (FloatingActionButton)findViewById(R.id.postCampaign);
        floatingActionButton.setVisibility(View.GONE);
        recyclerView=(RecyclerView)findViewById(R.id.recycler_view);
        disasterList = new ArrayList<SingleDisasterModel>();
        if(category!=null)
        {
            sendRequest(category);
        }
    }

    private void sendRequest(String category) {

        JSONObject latestJson=null;
        switch (category)
        {
            case "latest":
                latestJson  = new JSONObject();
                try {
                    latestJson.put("latestFilter", "true");
                    latestJson.put("nearFilter", "false");
                    latestJson.put("lessTimeFilter", "false");
                    latestJson.put("popularFilter", "false");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;
            case "almost":
               latestJson = new JSONObject();
                try {
                    latestJson.put("latestFilter", "false");
                    latestJson.put("nearFilter", "true");
                    latestJson.put("lessTimeFilter", "false");
                    latestJson.put("popularFilter", "false");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;
            case "lesstime":
                 latestJson = new JSONObject();
                try {
                    latestJson.put("latestFilter", "false");
                    latestJson.put("nearFilter", "false");
                    latestJson.put("lessTimeFilter", "true");
                    latestJson.put("popularFilter", "false");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
               break;
            case "mostpopular":
                latestJson = new JSONObject();
                try {
                    latestJson.put("latestFilter", "false");
                    latestJson.put("nearFilter", "false");
                    latestJson.put("lessTimeFilter", "false");
                    latestJson.put("popularFilter", "true");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;
        }



        final JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Constants.SEARCH_CAMPAIGNER, latestJson ,new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response)
            {
                try {
                    int len = response.length();
                    for (int s = 0; s < len; s++)
                    {
                        JSONObject jsonObject = response.getJSONObject(s);
                        if(jsonObject.getString("active").equals("true"))
                        {
                            SingleDisasterModel disasterModel = new SingleDisasterModel();
                            disasterModel.setId(jsonObject.getString("id"));
                            disasterModel.setDisasterName(jsonObject.getString("title"));
                            disasterModel.setGoalAmount(jsonObject.getString("amount"));
                            disasterModel.setDonatedAmount(jsonObject.getString("totalDonations"));
                            disasterModel.setLocation(jsonObject.getString("location"));
                            disasterModel.setDateCity(jsonObject.getString("postedDate"));
                            JSONArray jsonArray1 = jsonObject.getJSONArray("images");
                            if (jsonArray1.length() > 0) {
                                JSONObject jsonObjectImage = jsonArray1.getJSONObject(0);
                                disasterModel.setImageUrl(jsonObjectImage.getString("imageUrl"));
                            } else {
                                disasterModel.setImageUrl("https://s3-us-west-2.amazonaws.com/easyfunding/test_campaign/12.png");
                            }
                            disasterList.add(disasterModel);
                        }

                    }
                    recyclerView.setAdapter( new DisasterSingleAdapter(disasterList, CommonCampaignsList.this) );
                    LinearLayoutManager llm = new LinearLayoutManager(getApplicationContext());
                    llm.setOrientation(LinearLayoutManager.VERTICAL);
                    recyclerView.setLayoutManager(llm);
                }catch (JSONException e){
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
               // progessBar.setVisibility(View.GONE);
                recyclerView.setVisibility(View.GONE);
               // textView.setVisibility(View.VISIBLE);
                String body = null;
                if (error instanceof TimeoutError || error instanceof NoConnectionError)
                {
                    Toast.makeText(getApplicationContext(), "ConnectionError",
                            Toast.LENGTH_LONG).show();
                } else if (error instanceof ServerError)
                {

                    Toast.makeText(getApplicationContext(), "ServerError",
                            Toast.LENGTH_LONG).show();
                } else if (error instanceof NetworkError)
                {
                    Toast.makeText(getApplicationContext(), "NetworkError",
                            Toast.LENGTH_LONG).show();

                }else if (error.networkResponse.data != null) {
                    try {
                        body = new String(error.networkResponse.data, "UTF-8");
                        JSONObject failJsonObject = new JSONObject(body);
                        new android.app.AlertDialog.Builder(CommonCampaignsList.this)
                                .setMessage(failJsonObject.getString("message"))
                                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.cancel();
                                    }
                                })
                                .show();
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(jsonArrayRequest);
    }
}
