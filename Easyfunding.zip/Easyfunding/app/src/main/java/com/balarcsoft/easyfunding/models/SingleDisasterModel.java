package com.balarcsoft.easyfunding.models;

/**
 * Created by BS-2 on 4/18/2016.
 */
public class SingleDisasterModel {
    String location;
    String dateCity;
    String goalAmount;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    String id;
    public String getDisasterName() {
        return disasterName;
    }

    public void setDisasterName(String disasterName) {
        this.disasterName = disasterName;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    String disasterName;
    String imageUrl;
    public String getDonatedAmount() {
        return donatedAmount;
    }

    public void setDonatedAmount(String donatedAmount) {
        this.donatedAmount = donatedAmount;
    }

    public String getGoalAmount() {
        return goalAmount;
    }

    public void setGoalAmount(String goalAmount) {
        this.goalAmount = goalAmount;
    }

    public String getDateCity() {
        return dateCity;
    }

    public void setDateCity(String dateCity) {
        this.dateCity = dateCity;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    String donatedAmount;
}
