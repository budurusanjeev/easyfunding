package com.balarcsoft.easyfunding.models;

import java.math.BigDecimal;

/**
 * Created by BS-2 on 4/19/2016.
 */
public class MyCampaignModel {
    String campaignName;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    String id;
    String campaignPostedDate;
    int campaignGoalAmount;
    private boolean isSelected;
    public String getCampaignImageUrl() {
        return campaignImageUrl;
    }

    public void setCampaignImageUrl(String campaignImageUrl) {
        this.campaignImageUrl = campaignImageUrl;
    }

    String campaignImageUrl;

    public int getCampaignPercentage() {
        return campaignPercentage;
    }

    public void setCampaignPercentage(int campaignPercentage) {
        this.campaignPercentage = campaignPercentage;
    }
    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean isSelected) {
        this.isSelected = isSelected;
    }
    int campaignPercentage;

    public String getCampaignName() {
        return campaignName;
    }

    public void setCampaignName(String campaignName) {
        this.campaignName = campaignName;
    }

    public String getCampaignPostedDate() {
        return campaignPostedDate;
    }

    public void setCampaignPostedDate(String campaignPostedDate) {
        this.campaignPostedDate = campaignPostedDate;
    }

    public int getCampaignGoalAmount() {
        return campaignGoalAmount;
    }

    public void setCampaignGoalAmount(int campaignGoalAmount) {
        this.campaignGoalAmount = campaignGoalAmount;
    }

    public BigDecimal getCampaignRaisedAmount() {
        return campaignRaisedAmount;
    }

    public void setCampaignRaisedAmount(BigDecimal campaignRaisedAmount) {
        this.campaignRaisedAmount = campaignRaisedAmount;
    }

    public String getLiked() {
        return liked;
    }

    public void setLiked(String liked) {
        this.liked = liked;
    }

    BigDecimal campaignRaisedAmount;
    String liked;
}
