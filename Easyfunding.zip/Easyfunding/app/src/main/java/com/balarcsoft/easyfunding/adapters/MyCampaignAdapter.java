package com.balarcsoft.easyfunding.adapters;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SwitchCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.balarcsoft.easyfunding.Constants;
import com.balarcsoft.easyfunding.EditCampaign;
import com.balarcsoft.easyfunding.PutAsyncTaskVisibleCampaign;
import com.balarcsoft.easyfunding.R;
import com.balarcsoft.easyfunding.SignupResponse;
import com.balarcsoft.easyfunding.models.MyCampaignModel;
import com.balarcsoft.easyfunding.utils.AppPreferences;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;
import com.nostra13.universalimageloader.core.display.FadeInBitmapDisplayer;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;

import java.util.ArrayList;

/**
 * Created by BS-2 on 4/19/2016.
 */
public class MyCampaignAdapter extends RecyclerView.Adapter<MyCampaignAdapter.DataObjectHolder> {
    public Activity context;
    AppPreferences appPreferences;
    DisplayImageOptions options;
    private ArrayList<MyCampaignModel> mDataset;

    public MyCampaignAdapter(ArrayList<MyCampaignModel> myDataset, Activity applicationContext) {
        this.mDataset = myDataset;
        this.context = applicationContext;
        appPreferences = new AppPreferences(context);

        options = new DisplayImageOptions.Builder()
                //.cacheInMemory(true)
                .imageScaleType(ImageScaleType.IN_SAMPLE_INT)
                        //.resetViewBeforeLoading(true)
                        //.cacheOnDisk(true)
                .considerExifParams(true)
                .bitmapConfig(Bitmap.Config.RGB_565)
                .displayer(new FadeInBitmapDisplayer(2000))
                .build();
//    Log.v("url cons", "url cons" + this.mDataset.get(0).getCampaignName());
    }

    @Override
    public MyCampaignAdapter.DataObjectHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.my_campaign_row, parent, false);

        DataObjectHolder dataObjectHolder = new DataObjectHolder(view);
        return dataObjectHolder;
    }

    @Override
    public void onBindViewHolder(final MyCampaignAdapter.DataObjectHolder holder, int position) {
        final int pos = position;
        holder.campaignName.setText(mDataset.get(position).getCampaignName());
        holder.campaignPostedDate.setText("Posted Date: " + mDataset.get(position).getCampaignPostedDate());
        holder.campaignLikes.setText(mDataset.get(position).getLiked() + " Likes");
        holder.switchVisible.setChecked(mDataset.get(position).isSelected());
        holder.campaignGoalAmount.setText("Goal: " + String.valueOf(mDataset.get(position).getCampaignGoalAmount()));
        holder.campaignRasiedAmount.setText("Raised: $" + String.valueOf(mDataset.get(position).getCampaignRaisedAmount()));
        holder.switchVisible.setTag(mDataset.get(position));

        holder.switchVisible.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                SwitchCompat cb = (SwitchCompat) v;
                MyCampaignModel contact = (MyCampaignModel) cb.getTag();
                contact.setSelected(cb.isChecked());
                mDataset.get(pos).setSelected(cb.isChecked());
                setCampaignVisibity(mDataset.get(pos).getId(), String.valueOf(cb.isChecked()));
            }
        });

        final ProgressDialog progressBar = new ProgressDialog(context);
        ImageLoader.getInstance().displayImage(mDataset.get(position).getCampaignImageUrl(), holder.campaignImage, options, new ImageLoadingListener() {
            @Override
            public void onLoadingStarted(String imageUri, View view) {

                progressBar.setIndeterminate(true);

            }

            @Override
            public void onLoadingFailed(String imageUri, View view, FailReason failReason) {

            }

            @Override
            public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
                progressBar.dismiss();
            }

            @Override
            public void onLoadingCancelled(String imageUri, View view) {
                progressBar.dismiss();
            }
        });
        holder.campaignPercentage.setProgress(mDataset.get(position).getCampaignPercentage());
        holder.cardview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                context.startActivity(new Intent(context, EditCampaign.class)
                        .putExtra("campaignerId", mDataset.get(pos).getId())
                        .putExtra("campaignName", mDataset.get(pos).getCampaignName()));
                appPreferences.setCampaignerId(mDataset.get(pos).getId());
                animate(holder);

            }
        });

    }

    private void setCampaignVisibity(String id, String status) {
        try {
            String url = Constants.SINGLE_CAMPAIGN_VISIBILITY + id;
            AppPreferences appPreferences = new AppPreferences(context);
            ArrayList arrayList = new ArrayList();
            arrayList.add(status);
            arrayList.add(url);
            arrayList.add(appPreferences.getSessionId());
            arrayList.add(appPreferences.getTokenId());
            Log.v("url", "url " + url);
            Log.v("status", "urlstatus " + status);
            new PutAsyncTaskVisibleCampaign() {
                @Override
                protected void onPostExecute(SignupResponse signupResponse) {
                    super.onPostExecute(signupResponse);
                    if (signupResponse.getResponse() != null) {
                        if (signupResponse.getResponse().equals("200")) {
                            Toast.makeText(context, "Success", Toast.LENGTH_LONG).show();

                        } else {
                            Toast.makeText(context, "UnSuccessful", Toast.LENGTH_LONG).show();
                        }
                    } else {
                        Toast.makeText(context, "Due to network issue unable to connect to server", Toast.LENGTH_LONG).show();
                    }
                }
            }.execute(arrayList);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void animate(RecyclerView.ViewHolder viewHolder) {
        final Animation animAnticipateOvershoot = AnimationUtils.loadAnimation(context, R.anim.anticipateovershoot_interpolator);
        viewHolder.itemView.setAnimation(animAnticipateOvershoot);
    }

    @Override
    public int getItemCount() {
        return mDataset.size();
    }

    public class DataObjectHolder extends RecyclerView.ViewHolder
            implements View
            .OnClickListener {
        public TextView campaignName, campaignPostedDate, campaignLikes, campaignGoalAmount, campaignRasiedAmount;
        public ProgressBar campaignPercentage;
        public ImageView campaignImage;
        public CardView cardview;
        public SwitchCompat switchVisible;
       // public MyCampaignModel myCampaignModel;

        public DataObjectHolder(View itemView) {
            super(itemView);
            campaignImage = (ImageView) itemView.findViewById(R.id.campaignImage);
            campaignName = (TextView) itemView.findViewById(R.id.campaignName);
            campaignPostedDate = (TextView) itemView.findViewById(R.id.campaignPostedDate);
            campaignGoalAmount = (TextView) itemView.findViewById(R.id.campaignGoalAmount);
            campaignRasiedAmount = (TextView) itemView.findViewById(R.id.campaignRaisedAmount);
            campaignPercentage = (ProgressBar) itemView.findViewById(R.id.campaignPercentage);
            campaignLikes = (TextView) itemView.findViewById(R.id.campaignLikes);
            cardview = (CardView) itemView.findViewById(R.id.cardView);
            switchVisible = (SwitchCompat) itemView.findViewById(R.id.Switch);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {

        }
    }


}
