package com.balarcsoft.easyfunding.get;

import android.os.AsyncTask;
import android.util.Log;

import com.balarcsoft.easyfunding.SignupResponse;

import java.util.ArrayList;

/**
 * Created by BS2 on 02-07-2015.
 */
public class GetAsyncTask extends AsyncTask<ArrayList,String,SignupResponse> {
    SignupResponse signupResponse;

    @Override
    protected SignupResponse doInBackground(ArrayList... params) {

       String url = (String) params[0].get(0);
       String profile=(String) params[0].get(1);
       String sessionId =(String)params[0].get(2);
       String token =(String)params[0].get(3);
        String postReceiverUrl = url+profile;
        Log.v("TAG", "postURL: " + postReceiverUrl);
        signupResponse = GetwebServiceDatanew.getWebServiceData(postReceiverUrl,sessionId,token);
        Log.v("response","response"+signupResponse.getResponse());
        Log.v("response","response"+signupResponse.getResult());


    return signupResponse;
    }

}
