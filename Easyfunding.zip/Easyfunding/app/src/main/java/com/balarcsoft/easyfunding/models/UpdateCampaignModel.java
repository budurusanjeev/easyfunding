package com.balarcsoft.easyfunding.models;

/**
 * Created by BS-2 on 4/29/2016.
 */
public class UpdateCampaignModel {
    String postedDate;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    String id;
    public String getUpdatedComment() {
        return updatedComment;
    }

    public void setUpdatedComment(String updatedComment) {
        this.updatedComment = updatedComment;
    }

    public String getPostedDate() {
        return postedDate;
    }

    public void setPostedDate(String postedDate) {
        this.postedDate = postedDate;
    }

    String updatedComment;
}
