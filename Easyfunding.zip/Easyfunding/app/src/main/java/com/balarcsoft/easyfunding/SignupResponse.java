package com.balarcsoft.easyfunding;

/**
 * Created by BS2 on 29-01-2016.
 */
public class SignupResponse {
    private String response,result;

    public SignupResponse(String responseCode, String response) {
        this.response=responseCode;
        this.result=response;
    }

    public String getResponse() {
        return response;
    }

    public String getResult() {
        return result;
    }
}
